// esp32-data-service.js
// Service to handle ESP32 and Python decoder data collection

import { 
  getFirestore, 
  doc, 
  updateDoc, 
  arrayUnion, 
  setDoc, 
  getDoc, 
  collection, 
  addDoc,
  serverTimestamp,
  query,
  orderBy,
  limit,
  getDocs
} from "https://www.gstatic.com/firebasejs/11.4.0/firebase-firestore.js";
import { app } from "./firebase-config.js";

const db = getFirestore(app);

// Configuration: allow overriding ESP32 base URL via localStorage('ESP32_IP')
export function getESP32BaseUrl() {
  try {
    const v = localStorage.getItem('ESP32_IP');
    if (v && /^https?:\/\//.test(v)) return v.replace(/\/$/, '');
  } catch {}
  return "http://192.168.1.14"; // fallback default
}

export const ESP32_IP = getESP32BaseUrl();
// Use a different port for the Python decoder to avoid clashing with the local AI server
// AI server (chat): http://localhost:5000
// Decoder (weight/metrics API): http://localhost:5002
export const PYTHON_DECODER_URL = "http://localhost:5002";

// Function to collect data from Python decoder (the brain)
export async function collectAndSaveHealthData() {
  try {
    // Get current student LRN from localStorage
    const studentLRN = localStorage.getItem('studentLRN');
    if (!studentLRN) {
      console.error('No student LRN found in localStorage');
      return null;
    }

    console.log('Collecting health data for student LRN:', studentLRN);

    // First, set current student in Python decoder
    await fetch(`${PYTHON_DECODER_URL}/set_student`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ student_id: studentLRN })
    });

    // Fetch processed data from Python decoder (weight & body composition)
    const decoderResponse = await fetch(`${PYTHON_DECODER_URL}/data`);
    const healthData = await decoderResponse.json();

    // Fetch live data from ESP32 (/data) for height and status
    let espData = null;
    try {
      const resp = await fetch(`${ESP32_IP}/data`, { method: 'GET' });
      if (resp.ok) {
        espData = await resp.json();
      }
    } catch (e) {
      console.warn('ESP32 /data fetch failed:', e);
    }

    // Check if data is available and valid
    if (!healthData || healthData.error || healthData.status === 'waiting') {
      console.warn('No data available from Python decoder:', healthData);
      return null;
    }

    if (!healthData.weight || healthData.weight === 0) {
      console.warn('No valid weight data from decoder:', healthData);
      return null;
    }

    // Prefer height from ESP32 if available; otherwise keep placeholder
    let height = 170;
    if (espData && typeof espData.height === 'number' && espData.height > 0) {
      height = espData.height;
    }

    // Use BMI/bodyFat/muscle from decoder when present; fallback to compute BMI
    let bmi = parseFloat(healthData.bmi || 0);
    const bodyFat = parseFloat(healthData.body_fat || 0);
    const muscle = parseFloat(healthData.muscle_mass || 0);
    const weight = parseFloat(healthData.weight);

    if (!bmi || bmi === 0) {
      // compute from weight (kg) and height (cm)
      const hM = height / 100.0;
      if (hM > 0) bmi = parseFloat((weight / (hM * hM)).toFixed(1));
    }

    // Create health record from combined data
    const healthRecord = {
      timestamp: new Date(),
      height: parseFloat(height),
      weight: weight,
      bmi: bmi,
      bodyFat: bodyFat,
      muscle: muscle,
      impedance: espData && typeof espData.impedance !== 'undefined' ? espData.impedance : undefined,
      hasValidData: !!(espData && espData.hasValidData),
      source: 'combined_esp32_scale',
      // Add a reference to the student document
      studentLRN: studentLRN
    };

    // Save to Firestore in the student's health_metrics subcollection
    try {
      const studentRef = doc(db, 'students', studentLRN);
      const metricsRef = collection(studentRef, 'health_metrics');
      
      // Add the health record to the student's health_metrics subcollection
      await addDoc(metricsRef, healthRecord);
      
      // Also update the latestReading field in the student document
      await updateDoc(studentRef, {
        latestReading: {
          ...healthRecord,
          timestamp: serverTimestamp()
        }
      });
      
      console.log('Health data saved successfully for student:', studentLRN);
    } catch (error) {
      console.error('Error saving health data to Firestore:', error);
      throw error;
    }

    return healthRecord;

  } catch (error) {
    console.error('Error collecting and saving health data:', error);
    return null;
  }
}

// Function to get latest health data for a student
export async function getLatestHealthData(studentLRN) {
  try {
    // First try to get from the latestReading field (faster)
    const studentDocRef = doc(db, "students", studentLRN);
    const studentDoc = await getDoc(studentDocRef);

    if (!studentDoc.exists()) {
      console.log('Student document not found for LRN:', studentLRN);
      return null;
    }

    const studentData = studentDoc.data();
    if (studentData.latestReading) {
      return studentData.latestReading;
    }

    // Fallback: Query the health_metrics subcollection
    const metricsRef = collection(studentDocRef, 'health_metrics');
    const q = query(metricsRef, orderBy('timestamp', 'desc'), limit(1));
    const querySnapshot = await getDocs(q);
    
    if (!querySnapshot.empty) {
      const latestDoc = querySnapshot.docs[0];
      return { id: latestDoc.id, ...latestDoc.data() };
    }

    console.log('No health metrics found for student:', studentLRN);
    return null;
  } catch (error) {
    console.error('Error fetching latest health data:', error);
    return null;
  }
}

// Function to start periodic data collection (call this when student steps on scale)
export function startHealthDataCollection(intervalMs = 5000) {
  console.log('Starting health data collection...');
  
  const collectData = async () => {
    const result = await collectAndSaveHealthData();
    if (result) {
      console.log('Health data collected and saved:', result);
      // Stop collection after successful measurement
      clearInterval(collectionInterval);
      return result;
    }
  };

  // Collect data immediately
  collectData();
  
  // Then collect every intervalMs until successful
  const collectionInterval = setInterval(collectData, intervalMs);
  
  // Stop after 2 minutes if no successful measurement
  setTimeout(() => {
    clearInterval(collectionInterval);
    console.log('Health data collection timeout');
  }, 120000);

  return collectionInterval;
}
