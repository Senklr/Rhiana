// HIPAA-compliant cache names with version control
const CACHE_NAME = 'zenith-health-hipaa-v1.0.1';
const STATIC_CACHE = 'zenith-static-hipaa-v1.0.1';
const DYNAMIC_CACHE = 'zenith-dynamic-hipaa-v1.0.1';

// HIPAA-compliant: Files safe to cache (NO PHI or sensitive data)
const STATIC_ASSETS = [
  '/index.html',
  '/student-nurse.html',
  '/nurseview.html',
  '/student-view.html',
  '/student-info-form.html',
  '/install-guide.html',
  '/privacy-notice.html',
  '/settings.html',
  '/style.css',
  '/view.css',
  '/manifest.json'
  // REMOVED: auth.js, firebase-config.js, esp32-data-service.js (contain sensitive configs)
  // REMOVED: nurse-login.html, register.html (authentication pages)
];

// Firebase and external resources (cache with network fallback)
const EXTERNAL_RESOURCES = [
  'https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js',
  'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js',
  'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js',
  'https://www.gstatic.com/firebasejs/9.22.0/firebase-app.js',
  'https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js',
  'https://www.gstatic.com/firebasejs/9.22.0/firebase-firestore.js'
];

// HIPAA-compliant: Sensitive patterns that should NEVER be cached
const SENSITIVE_PATTERNS = [
  /firebase-config/,
  /auth\.js/,
  /login/,
  /register/,
  /password/,
  /token/,
  /api.*key/i,
  /secret/i,
  // HIPAA-specific PHI patterns
  /student.*data/i,
  /health.*record/i,
  /medical.*info/i,
  /patient.*data/i,
  /phi/i,
  /personal.*health/i,
  /lrn/i,
  /student.*id/i,
  /name.*age.*sex/i,
  /weight.*height.*bmi/i,
  /body.*composition/i
];

// Install event - cache static assets
self.addEventListener('install', event => {
  console.log('🔧 Service Worker: Installing...');
  
  event.waitUntil(
    Promise.all([
      // Cache static assets
      caches.open(STATIC_CACHE).then(cache => {
        console.log('📦 Service Worker: Caching static assets');
        return cache.addAll(STATIC_ASSETS.filter(url => !isSensitive(url)));
      }),
      // Cache external resources
      caches.open(DYNAMIC_CACHE).then(cache => {
        console.log('🌐 Service Worker: Caching external resources');
        return Promise.allSettled(
          EXTERNAL_RESOURCES.map(url => 
            cache.add(url).catch(err => {
              console.warn(`Failed to cache ${url}:`, err);
            })
          )
        );
      })
    ]).then(() => {
      console.log('✅ Service Worker: Installation complete');
      self.skipWaiting();
    })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
  console.log('🚀 Service Worker: Activating...');
  
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== STATIC_CACHE && 
              cacheName !== DYNAMIC_CACHE && 
              cacheName !== CACHE_NAME) {
            console.log('🗑️ Service Worker: Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      console.log('✅ Service Worker: Activation complete');
      return self.clients.claim();
    })
  );
});

// Fetch event - handle requests with caching strategy
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  
  // Skip non-GET requests
  if (request.method !== 'GET') {
    return;
  }
  
  // Skip sensitive requests
  if (isSensitive(request.url)) {
    console.log('🔒 Service Worker: Skipping sensitive request:', request.url);
    return;
  }
  
  // Handle different types of requests (order matters)
  if (isFirebaseRequest(request.url)) {
    // Firebase requests: Network only (never cache sensitive data)
    event.respondWith(handleFirebaseRequest(request));
  } else if (isAPIRequest(request.url)) {
    // API requests: Network first, limited cache
    event.respondWith(handleAPIRequest(request));
  } else if (isStaticAsset(request.url)) {
    // Static assets: Cache first, network fallback
    event.respondWith(handleStaticAsset(request));
  } else if (isExternalResource(request.url)) {
    // External resources: Network first, cache fallback
    event.respondWith(handleExternalResource(request));
  } else {
    // Other requests: Network first, cache fallback
    event.respondWith(handleGenericRequest(request));
  }
});

// Helper functions
function isSensitive(url) {
  return SENSITIVE_PATTERNS.some(pattern => pattern.test(url));
}

function isStaticAsset(url) {
  try {
    const u = new URL(url);
    // Only treat same-origin paths as static assets
    if (u.origin !== self.location.origin) return false;
    const path = u.pathname;
    // Exact path match for known static files
    if (STATIC_ASSETS.includes(path)) return true;
    // File extension-based static assets
    return /\.(css|js|html|png|jpg|jpeg|gif|svg|ico|woff2?|ttf)$/.test(path);
  } catch {
    return false;
  }
}

function isExternalResource(url) {
  return EXTERNAL_RESOURCES.some(resource => url.includes(resource)) ||
         url.includes('gstatic.com') ||
         url.includes('googleapis.com');
}

function isFirebaseRequest(url) {
  // Match Firebase/Firestore endpoints including googleapis domains
  return /firestore\.googleapis\.com|firebaseio\.com|firebase|identitytoolkit\.googleapis\.com/.test(url);
}

function isAPIRequest(url) {
  // Treat device/local APIs or custom app endpoints as API
  return /\/api\//.test(url) ||
         /\/data(\b|\/|\?|$)/.test(url) ||
         /esp32/i.test(url) ||
         /processor/i.test(url) ||
         // Local network IPs (e.g., ESP32 or local servers)
         /^https?:\/\/\d+\.\d+\.\d+\.\d+/.test(url);
}

// Cache strategies
async function handleStaticAsset(request) {
  try {
    const cache = await caches.open(STATIC_CACHE);
    const cachedResponse = await cache.match(request);
    
    if (cachedResponse) {
      console.log('📦 Service Worker: Serving from cache:', request.url);
      return cachedResponse;
    }
    
    console.log('🌐 Service Worker: Fetching static asset:', request.url);
    const networkResponse = await fetch(request);
    
    if (networkResponse.ok) {
      cache.put(request, networkResponse.clone());
    }
    
    return networkResponse;
  } catch (error) {
    console.error('❌ Service Worker: Static asset failed:', error);
    return new Response('Offline - Asset not available', { 
      status: 503,
      statusText: 'Service Unavailable'
    });
  }
}

async function handleExternalResource(request) {
  try {
    console.log('🌐 Service Worker: Fetching external resource:', request.url);
    const networkResponse = await fetch(request, { 
      mode: 'cors',
      credentials: 'omit'
    });
    
    if (networkResponse.ok) {
      const cache = await caches.open(DYNAMIC_CACHE);
      cache.put(request, networkResponse.clone());
    }
    
    return networkResponse;
  } catch (error) {
    console.log('📦 Service Worker: Network failed, trying cache:', request.url);
    const cache = await caches.open(DYNAMIC_CACHE);
    const cachedResponse = await cache.match(request);
    
    if (cachedResponse) {
      return cachedResponse;
    }
    
    console.error('❌ Service Worker: External resource unavailable:', error);
    return new Response('External resource unavailable offline', {
      status: 503,
      statusText: 'Service Unavailable'
    });
  }
}

async function handleFirebaseRequest(request) {
  // Firebase requests should never be cached for security
  try {
    console.log('🔥 Service Worker: Firebase request (network only):', request.url);
    return await fetch(request);
  } catch (error) {
    console.error('❌ Service Worker: Firebase request failed:', error);
    return new Response(JSON.stringify({
      error: 'Firebase service unavailable offline',
      offline: true
    }), {
      status: 503,
      statusText: 'Service Unavailable',
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

async function handleAPIRequest(request) {
  try {
    console.log('🔌 Service Worker: API request:', request.url);
    const networkResponse = await fetch(request);
    
    // Only cache successful, non-sensitive API responses
    if (networkResponse.ok && !isSensitive(request.url)) {
      const cache = await caches.open(DYNAMIC_CACHE);
      // Set a short TTL for API responses
      const response = networkResponse.clone();
      const headers = new Headers(response.headers);
      headers.set('sw-cached-at', Date.now().toString());
      
      cache.put(request, new Response(response.body, {
        status: response.status,
        statusText: response.statusText,
        headers: headers
      }));
    }
    
    return networkResponse;
  } catch (error) {
    console.log('📦 Service Worker: API network failed, trying cache:', request.url);
    const cache = await caches.open(DYNAMIC_CACHE);
    const cachedResponse = await cache.match(request);
    
    if (cachedResponse) {
      // Check if cached response is still fresh (5 minutes)
      const cachedAt = cachedResponse.headers.get('sw-cached-at');
      const now = Date.now();
      const fiveMinutes = 5 * 60 * 1000;
      
      if (cachedAt && (now - parseInt(cachedAt)) < fiveMinutes) {
        console.log('📦 Service Worker: Serving fresh cached API response');
        return cachedResponse;
      }
    }
    
    console.error('❌ Service Worker: API request failed:', error);
    return new Response(JSON.stringify({
      error: 'API service unavailable offline',
      offline: true,
      message: 'Please check your internet connection'
    }), {
      status: 503,
      statusText: 'Service Unavailable',
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

async function handleGenericRequest(request) {
  try {
    console.log('🌐 Service Worker: Generic request:', request.url);
    const networkResponse = await fetch(request);
    
    if (networkResponse.ok && !isSensitive(request.url)) {
      const cache = await caches.open(DYNAMIC_CACHE);
      cache.put(request, networkResponse.clone());
    }
    
    return networkResponse;
  } catch (error) {
    console.log('📦 Service Worker: Generic network failed, trying cache:', request.url);
    const cache = await caches.open(DYNAMIC_CACHE);
    const cachedResponse = await cache.match(request);
    
    if (cachedResponse) {
      return cachedResponse;
    }
    
    console.error('❌ Service Worker: Generic request failed:', error);
    return new Response('Content unavailable offline', {
      status: 503,
      statusText: 'Service Unavailable'
    });
  }
}

// Background sync for when connection is restored
self.addEventListener('sync', event => {
  if (event.tag === 'background-sync') {
    console.log('🔄 Service Worker: Background sync triggered');
    event.waitUntil(syncData());
  }
});

async function syncData() {
  try {
    // Attempt to sync any pending data when connection is restored
    console.log('🔄 Service Worker: Syncing data...');
    
    // Clear old cached API responses to get fresh data
    const cache = await caches.open(DYNAMIC_CACHE);
    const requests = await cache.keys();
    
    for (const request of requests) {
      if (isAPIRequest(request.url)) {
        await cache.delete(request);
      }
    }
    
    console.log('✅ Service Worker: Data sync complete');
  } catch (error) {
    console.error('❌ Service Worker: Sync failed:', error);
  }
}

// Handle push notifications (if needed in future)
self.addEventListener('push', event => {
  if (event.data) {
    const data = event.data.json();
    console.log('📱 Service Worker: Push notification received:', data);
    
    const options = {
      body: data.body || 'New health data available',
      icon: '/icons/icon-192x192.png',
      badge: '/icons/icon-72x72.png',
      vibrate: [100, 50, 100],
      data: data.data || {},
      actions: [
        {
          action: 'view',
          title: 'View',
          icon: '/icons/icon-72x72.png'
        },
        {
          action: 'dismiss',
          title: 'Dismiss'
        }
      ]
    };
    
    event.waitUntil(
      self.registration.showNotification(data.title || 'ZENITH Health', options)
    );
  }
});

// Handle notification clicks
self.addEventListener('notificationclick', event => {
  console.log('📱 Service Worker: Notification clicked:', event.action);
  
  event.notification.close();
  
  if (event.action === 'view') {
    event.waitUntil(
      clients.openWindow('/')
    );
  }
});

console.log('🩺 ZENITH Health Service Worker loaded successfully');
