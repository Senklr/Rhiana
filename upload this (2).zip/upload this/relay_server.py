import os
import json
import time
from flask import Flask, request, jsonify
from flask_cors import CORS
import firebase_admin
from firebase_admin import credentials, firestore, db as rtdb
from datetime import datetime

# ---- Config via ENV ----
# Required: RELAY_API_KEY (simple shared secret)
RELAY_API_KEY = os.getenv("RELAY_API_KEY", "")
# Either provide service account JSON content via ENV, or a path to a JSON file in the filesystem
FIREBASE_SERVICE_ACCOUNT_JSON = os.getenv("FIREBASE_SERVICE_ACCOUNT_JSON", "")
FIREBASE_SERVICE_ACCOUNT_PATH = os.getenv("FIREBASE_SERVICE_ACCOUNT_PATH", "zenith-software-2295d-firebase-adminsdk-fbsvc-28f21134ea.json")
FIREBASE_PROJECT_ID = os.getenv("FIREBASE_PROJECT_ID", "zenith-software-2295d")
RTDB_URL = os.getenv("RTDB_URL", "")  # e.g. https://<rtdb-name>.asia-southeast1.firebasedatabase.app
MIRROR_RTDB = os.getenv("MIRROR_RTDB", "true").lower() == "true"

if not RELAY_API_KEY:
    print("[WARN] RELAY_API_KEY is not set; set it in your deployment environment")

# ---- Firebase Admin init ----
cred = None
if FIREBASE_SERVICE_ACCOUNT_JSON:
    try:
        data = json.loads(FIREBASE_SERVICE_ACCOUNT_JSON)
        cred = credentials.Certificate(data)
    except Exception as e:
        raise RuntimeError(f"Invalid FIREBASE_SERVICE_ACCOUNT_JSON: {e}")
elif os.path.exists(FIREBASE_SERVICE_ACCOUNT_PATH):
    cred = credentials.Certificate(FIREBASE_SERVICE_ACCOUNT_PATH)
else:
    raise RuntimeError("No service account provided. Set FIREBASE_SERVICE_ACCOUNT_JSON or FIREBASE_SERVICE_ACCOUNT_PATH")

_cfg = {"projectId": FIREBASE_PROJECT_ID}
if RTDB_URL:
    _cfg["databaseURL"] = RTDB_URL
app = firebase_admin.initialize_app(cred, _cfg)
db = firestore.client()

# ---- Flask app ----
app = Flask(__name__)
CORS(app)


def require_api_key(req):
    # If no API key configured, disable auth (useful for local testing)
    if not RELAY_API_KEY:
        return True
    key = req.headers.get("X-API-Key", "")
    return key == RELAY_API_KEY


@app.route("/health", methods=["GET"]) 
def health():
    return jsonify({
        "ok": True,
        "time": datetime.utcnow().isoformat() + "Z",
        "rtdbConfigured": bool(RTDB_URL),
        "mirrorRTDB": bool(MIRROR_RTDB),
    })


@app.route("/selectNewest", methods=["POST"]) 
def select_newest():
    if not require_api_key(request):
        return jsonify({"error": "unauthorized"}), 401

    payload = request.get_json(silent=True) or {}
    with_null = bool(payload.get("withNullMetrics", False))

    col = db.collection("students")
    q = col
    if with_null:
        # Use dotted field paths for nested keys; may require composite index.
        try:
            q = q.where("metrics.weight", "==", None) \
                 .where("metrics.height", "==", None) \
                 .where("metrics.bmi", "==", None)
        except Exception:
            # Fallback: ignore the null filter if client library/version has issues
            pass

    # Try multiple strategies to find the newest student
    def try_query(order_field):
        try:
            return list(q.order_by(order_field, direction=firestore.Query.DESCENDING).limit(1).stream())
        except Exception:
            return []

    docs = try_query("createdAt")
    if not docs:
        docs = try_query("updatedAt")
    if not docs:
        # Some installs only update latestReading.timestamp; try ordering by that nested field
        docs = try_query("latestReading.timestamp")
    if not docs:
        # As a last resort, scan a small window and pick by whichever timestamp exists
        candidates = list(col.limit(50).stream())
        if not candidates:
            return jsonify({"error": "no_document"}), 404
        def ts_of(doc):
            d = doc.to_dict() or {}
            # Prefer createdAt, then updatedAt, then latestReading.timestamp
            for k in ("createdAt", "updatedAt"):
                if d.get(k):
                    return d.get(k)
            lr = d.get("latestReading") or {}
            return lr.get("timestamp")
        docs = [max(candidates, key=ts_of)]

    d = docs[0]
    data = d.to_dict() or {}
    # Ensure LRN is serialized as a string to avoid truncation or type surprises
    lrn_val = data.get("studentLRN", "")
    try:
        lrn_str = str(lrn_val) if lrn_val is not None else ""
    except Exception:
        lrn_str = ""
    resp = {
        "docId": d.id,
        "studentLRN": lrn_str,
        "age": data.get("age"),
        "sex": data.get("sex"),
        "createdAt": data.get("createdAt").isoformat() if data.get("createdAt") else None,
    }
    return jsonify(resp)


@app.route("/uploadMetrics", methods=["POST"]) 
def upload_metrics():
    if not require_api_key(request):
        return jsonify({"error": "unauthorized"}), 401

    payload = request.get_json(silent=True) or {}
    doc_id = payload.get("docId")
    student_lrn = payload.get("studentLRN")
    metrics = payload.get("metrics") or {}

    # Try to resolve a student target; if we can't, we will fallback to an "uploads" collection
    target_ref = None
    fallback_unassigned = False
    if doc_id:
        target_ref = db.collection("students").document(doc_id)
    elif student_lrn:
        # Resolve by LRN; try string match first, then numeric match for legacy data
        docs = list(db.collection("students").where("studentLRN", "==", str(student_lrn)).limit(1).stream())
        if not docs:
            try:
                lrn_num = int(student_lrn)
                docs = list(db.collection("students").where("studentLRN", "==", lrn_num).limit(1).stream())
            except Exception:
                docs = []
        if docs:
            target_ref = docs[0].reference
        else:
            fallback_unassigned = True
    else:
        # Neither docId nor LRN supplied
        fallback_unassigned = True

    # Prepare update; allow numeric or None to clear
    # Normalize body fat key
    bf = metrics.get("body_fat_percent")
    if bf is None:
        bf = metrics.get("body_fat_percentage")
    upd = {
        "metrics.weight": metrics.get("weight"),
        "metrics.height": metrics.get("height"),
        "metrics.bmi": metrics.get("bmi"),
        "metrics.muscle_mass": metrics.get("muscle_mass"),
        # Use canonical key body_fat_percent going forward
        "metrics.body_fat_percent": bf,
        "updatedAt": firestore.SERVER_TIMESTAMP,
    }

    # Also persist a latestReading object for UIs that listen to students/{lrn}.latestReading
    # Field names align with frontend expectations in student-view.html
    upd["latestReading"] = {
        "weight": metrics.get("weight"),
        "height": metrics.get("height"),
        "bmi": metrics.get("bmi"),
        # Frontend expects body_fat_percent and muscle_mass keys
        "body_fat_percent": bf,
        "muscle_mass": metrics.get("muscle_mass"),
        "timestamp": firestore.SERVER_TIMESTAMP,
    }

    # Ensure createdAt exists for robust selection later
    try:
        snap = target_ref.get()
        d = snap.to_dict() if snap.exists else None
        if not d or not d.get("createdAt"):
            upd["createdAt"] = firestore.SERVER_TIMESTAMP
    except Exception:
        # If read fails, proceed without conditional and avoid crashing
        pass

    if not fallback_unassigned:
        # Firestore write into students/{doc}
        target_ref.set(upd, merge=True)
    else:
        # Fallback path: accept upload into a general uploads collection
        try:
            rec = {
                "studentLRN": student_lrn,
                "docId": doc_id,
                "metrics": {
                    "weight": metrics.get("weight"),
                    "height": metrics.get("height"),
                    "bmi": metrics.get("bmi"),
                    "body_fat_percent": bf,
                    "muscle_mass": metrics.get("muscle_mass"),
                },
                "receivedAt": firestore.SERVER_TIMESTAMP,
            }
            uploads_ref = db.collection("uploads")
            new_doc_ref = uploads_ref.document()
            new_doc_ref.set(rec)
            # Optional RTDB mirror for unassigned
            if MIRROR_RTDB and RTDB_URL:
                try:
                    ts_ms = int(time.time() * 1000)
                    latest = {
                        "weight": metrics.get("weight"),
                        "height": metrics.get("height"),
                        "bmi": metrics.get("bmi"),
                        "body_fat_percent": bf,
                        "muscle_mass": metrics.get("muscle_mass"),
                        # Use numeric epoch millis for RTDB (avoid Firestore sentinel)
                        "timestamp": ts_ms,
                    }
                    rtdb.reference(f"uploads/unassigned/{new_doc_ref.id}").set(latest)
                except Exception as e:
                    print(f"[WARN] RTDB mirror (unassigned) failed: {e}")
            return jsonify({"ok": True, "unassignedId": new_doc_ref.id})
        except Exception as e:
            return jsonify({"error": "unassigned_store_failed", "details": str(e)}), 500

    # Optional: mirror latestReading into RTDB for device/front-end listeners
    lrn_to_use = None
    if student_lrn:
        lrn_to_use = str(student_lrn)
    else:
        try:
            if snap and (d or {}).get("studentLRN") is not None:
                lrn_to_use = str(d.get("studentLRN"))
        except Exception:
            lrn_to_use = None

    if not fallback_unassigned and MIRROR_RTDB and RTDB_URL and lrn_to_use:
        try:
            ts_ms = int(time.time() * 1000)
            latest = {
                "weight": metrics.get("weight"),
                "height": metrics.get("height"),
                "bmi": metrics.get("bmi"),
                "body_fat_percent": bf,
                "muscle_mass": metrics.get("muscle_mass"),
                # Use numeric epoch millis for RTDB (avoid Firestore sentinel)
                "timestamp": ts_ms,
            }
            rtdb.reference(f"students/{lrn_to_use}/latestReading").set(latest)
        except Exception as e:
            # Log but do not fail the API since Firestore already succeeded
            print(f"[WARN] RTDB mirror failed for {lrn_to_use}: {e}")

    return jsonify({"ok": True})


if __name__ == "__main__":
    # Local run only. In Cloud Run/Render, the platform will invoke the app.
    port = int(os.getenv("PORT", "5000"))
    app.run(host="0.0.0.0", port=port)
