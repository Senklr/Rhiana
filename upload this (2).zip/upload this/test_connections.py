#!/usr/bin/env python3
"""
ZENITH System Connection Test
Tests all connections: Python services, HTML form, ESP32, Firestore
"""

import requests
import json
import time

def test_credential_processor():
    """Test credential processor API"""
    try:
        response = requests.get("http://localhost:5001/health", timeout=3)
        if response.status_code == 200:
            data = response.json()
            print("✅ Credential Processor: ONLINE")
            print(f"   Firebase: {'✅' if data.get('firebase_connected') else '❌'}")
            return True
        else:
            print(f"❌ Credential Processor: HTTP {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Credential Processor: OFFLINE ({e})")
        return False

def test_scale_decoder():
    """Test scale decoder API"""
    try:
        response = requests.get("http://localhost:5000/data", timeout=3)
        if response.status_code == 200:
            print("✅ Scale Decoder: ONLINE")
            return True
        else:
            print(f"❌ Scale Decoder: HTTP {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Scale Decoder: OFFLINE ({e})")
        return False

def test_student_registration():
    """Test student registration flow"""
    try:
        student_data = {
            "studentLRN": "123456789012",
            "name": "Test Student",
            "section": "03",
            "strand": "STEM",
            "grade": 11,
            "age": 16,
            "sex": "Male"
        }
        
        response = requests.post(
            "http://localhost:5001/register_student",
            json=student_data,
            timeout=5
        )
        
        if response.status_code == 200:
            result = response.json()
            if result.get('success'):
                print("✅ Student Registration: WORKING")
                print(f"   Folder: {result.get('folder_name', 'N/A')}")
                return True
            else:
                print(f"❌ Student Registration: {result.get('error', 'Unknown error')}")
                return False
        else:
            print(f"❌ Student Registration: HTTP {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Student Registration: FAILED ({e})")
        return False

def test_measurement_flow():
    """Test measurement data flow"""
    try:
        measurement_data = {
            "weight": 60.5,
            "height": 170.2,
            "bmi": 20.9,
            "timestamp": "2025-08-26T20:45:00",
            "status": "completed"
        }
        
        response = requests.post(
            "http://localhost:5001/receive_measurement",
            json=measurement_data,
            timeout=5
        )
        
        if response.status_code == 200:
            result = response.json()
            if result.get('success'):
                print("✅ Measurement Flow: WORKING")
                print(f"   Record ID: {result.get('record', {}).get('measurement_id', 'N/A')}")
                return True
            else:
                print(f"❌ Measurement Flow: {result.get('error', 'Unknown error')}")
                return False
        else:
            print(f"❌ Measurement Flow: HTTP {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Measurement Flow: FAILED ({e})")
        return False

def main():
    print("🔍 ZENITH SYSTEM CONNECTION TEST")
    print("=" * 40)
    
    # Test individual services
    print("\n📡 Testing Backend Services:")
    cp_ok = test_credential_processor()
    sd_ok = test_scale_decoder()
    
    if not (cp_ok and sd_ok):
        print("\n❌ Backend services not running!")
        print("   Start both services first:")
        print("   python student_credential_processor.py")
        print("   python xiaomi_scale_decoder.py")
        return
    
    # Test data flow
    print("\n🔄 Testing Data Flow:")
    reg_ok = test_student_registration()
    
    if reg_ok:
        time.sleep(1)  # Brief pause
        meas_ok = test_measurement_flow()
    else:
        meas_ok = False
    
    # Summary
    print("\n📊 SYSTEM STATUS:")
    print(f"   Backend Services: {'✅' if (cp_ok and sd_ok) else '❌'}")
    print(f"   Student Registration: {'✅' if reg_ok else '❌'}")
    print(f"   Measurement Processing: {'✅' if meas_ok else '❌'}")
    
    if cp_ok and sd_ok and reg_ok and meas_ok:
        print("\n🎯 SYSTEM FULLY OPERATIONAL!")
        print("   Ready for ESP32 and web form testing")
    else:
        print("\n⚠️  SYSTEM ISSUES DETECTED")
        print("   Check service logs for details")

if __name__ == "__main__":
    main()
