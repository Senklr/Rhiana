#!/usr/bin/env python3
"""
ZENITH Health System - Simple AI Server (No Authentication Required)
Uses a public model that doesn't need Hugging Face login
"""

import os
import json
import logging
from datetime import datetime
from flask import Flask, request, jsonify, make_response
from flask_cors import CORS
import re

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

class SimpleHealthcareAI:
    def __init__(self):
        # PHI patterns kept for potential future use, but not enforced
        self.phi_patterns = [
            r'\b\d{3}-\d{2}-\d{4}\b',
            r'\b[A-Z]{2,3}-\d{3,6}\b',
            r'\b\d{10,}\b',
            r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        ]
        
        # Healthcare knowledge base
        self.healthcare_responses = {
            'hand_hygiene': [
                "**Hand Hygiene Best Practices:**\n\n• **When to wash**: Before/after patient contact, after removing gloves, before eating\n• **Technique**: 20 seconds with soap and water, or alcohol-based sanitizer\n• **Critical moments**: Before aseptic procedures, after body fluid exposure\n• **Compliance**: Use WHO's 5 Moments for Hand Hygiene as guidance",
                
                "**Proper Hand Hygiene Steps:**\n\n1. **Wet hands** with clean running water\n2. **Apply soap** and lather well\n3. **Scrub for 20 seconds** - all surfaces including between fingers\n4. **Rinse thoroughly** under running water\n5. **Dry with clean towel** or air dry\n\n**Alternative**: Alcohol-based hand rub (60%+ alcohol) when hands not visibly soiled"
            ],
            
            'infection_control': [
                "**Infection Control Protocols:**\n\n• **Standard Precautions**: Treat all patients as potentially infectious\n• **PPE Usage**: Gloves, gowns, masks, eye protection as appropriate\n• **Environmental Cleaning**: Regular disinfection of surfaces and equipment\n• **Isolation Precautions**: Contact, droplet, or airborne as indicated\n• **Waste Management**: Proper disposal of contaminated materials",
                
                "**Key Infection Prevention Strategies:**\n\n• **Hand hygiene** - most important measure\n• **Vaccination** - stay current with immunizations\n• **Safe injection practices** - one needle, one syringe, one use\n• **Respiratory etiquette** - cover coughs and sneezes\n• **Environmental controls** - proper ventilation and cleaning"
            ],
            
            'documentation': [
                "**Documentation Best Practices:**\n\n• **Accuracy**: Record only factual, objective observations\n• **Timeliness**: Document as soon as possible after care\n• **Completeness**: Include all relevant patient interactions\n• **Legibility**: Ensure all entries are readable\n• **Confidentiality**: Maintain HIPAA compliance in all records",
                
                "**Effective Nursing Documentation:**\n\n• **Use standard terminology** and approved abbreviations\n• **Include date, time, and signature** on all entries\n• **Avoid subjective language** - stick to observable facts\n• **Document patient responses** to interventions\n• **Follow facility policies** for corrections and late entries"
            ],
            
            'patient_safety': [
                "**Patient Safety Priorities:**\n\n• **Medication Safety**: Verify patient identity and medication accuracy (5 Rights)\n• **Fall Prevention**: Assess risk factors and implement preventive measures\n• **Communication**: Clear, effective communication among healthcare team\n• **Emergency Preparedness**: Know location of emergency equipment and protocols\n• **Incident Reporting**: Report safety concerns promptly and accurately",
                
                "**The 5 Rights of Medication Administration:**\n\n1. **Right Patient** - verify identity with 2 identifiers\n2. **Right Drug** - check medication name and strength\n3. **Right Dose** - verify correct amount\n4. **Right Route** - confirm method of administration\n5. **Right Time** - administer at prescribed intervals\n\n**Plus**: Right documentation and right to refuse"
            ],
            
            'wellness': [
                "**Student Wellness Promotion:**\n\n• **Physical Health**: Encourage regular exercise, proper nutrition, adequate sleep\n• **Mental Health**: Provide stress management resources and emotional support\n• **Preventive Care**: Promote regular health screenings and immunizations\n• **Health Education**: Teach about healthy lifestyle choices\n• **Social Support**: Foster healthy relationships and community involvement",
                
                "**Key Wellness Areas:**\n\n• **Nutrition**: Balanced diet with fruits, vegetables, whole grains\n• **Physical Activity**: 150 minutes moderate exercise per week\n• **Sleep Hygiene**: 7-9 hours quality sleep nightly\n• **Stress Management**: Relaxation techniques, time management\n• **Preventive Care**: Regular check-ups, screenings, vaccinations"
            ],

            'weight_management': [
                "**Underweight (General Guidance, Non‑diagnostic)**\n\nThis guidance is educational and not a diagnosis. For persistent concerns, consult a clinician or registered nutritionist‑dietitian.\n\n• **Energy‑dense, nutrient‑rich foods**: Add healthy fats (olive oil, peanut butter, avocado), nuts, seeds; include dairy or fortified alternatives.\n• **Regular meal pattern**: 3 meals + 2–3 snacks/day; avoid skipping meals.\n• **Protein at each meal**: Eggs, fish, chicken, tofu/tempeh, legumes; aim ~0.8–1.2 g/kg/day as age‑appropriate (consult clinician for personalized intake).\n• **Carbohydrates for fuel**: Rice, potatoes, oats, whole‑grain bread/pasta; pair with proteins and vegetables.\n• **Strength training**: 2–3×/week to support lean mass gain (age‑appropriate exercises; supervise youth).\n• **Milk/yogurt smoothies**: Add fruits, peanut butter, oats for extra calories.\n• **Hydration**: Prefer water and milk; limit low‑calorie fillers before meals.\n• **Sleep and stress**: 7–9 hours; manage stress for appetite regulation.\n\nReferences:\n[1] WHO. Healthy diet. Updated 2024. https://www.who.int/news-room/fact-sheets/detail/healthy-diet\n[2] DOH (Philippines). Pinggang Pinoy® Food Plate. https://www.doh.gov.ph/ and FNRI‑DOST resources\n[3] WHO. Physical activity for health. 2020 Guidelines. https://www.who.int/publications/i/item/9789240015128",

                "**Healthy Weight (General WHO/DOH‑aligned Habits)**\n\n• **WHO Healthy Plate** / **Pinggang Pinoy®**: Half plate vegetables/fruits, quarter protein, quarter whole grains; include water and fruit as dessert.\n• **Routine activity**: Follow WHO guidelines (children/adolescents: avg **60 min/day moderate‑to‑vigorous**; adults: 150–300 min/week moderate + 2–3 strength sessions).\n• **Balanced meals**: Combine carbohydrates + protein + vegetables + healthy fats.\n• **Limit sugar‑sweetened beverages**: Prefer water; keep added sugar low.\n• **Screen time & sleep**: Limit sedentary time; sleep 8–10 h (teens) or 7–9 h (adults).\n• **Preventive care**: Immunizations per DOH; routine deworming per local programs when applicable.\n\nReferences:\n[1] WHO. Physical activity guidelines (2020). https://www.who.int/publications/i/item/9789240015128\n[2] FNRI‑DOST/DOH. Pinggang Pinoy®. https://www.fnri.dost.gov.ph/\n[3] WHO. Healthy diet (Updated 2024). https://www.who.int/news-room/fact-sheets/detail/healthy-diet",

                "**Overweight/Obesity (General Guidance, Non‑diagnostic)**\n\nThis is educational guidance. Seek personalized care from a clinician when possible.\n\n• **Balanced plate approach**: Half vegetables/fruits; quarter lean protein; quarter whole grains (Pinggang Pinoy®).\n• **Portion awareness**: Eat slowly; use smaller plates; emphasize fiber and protein for satiety.\n• **Physical activity**: \n  – Adults: 150–300 min/week moderate or 75–150 min vigorous + 2–3 strength sessions.\n  – Youth (5–17 y): Avg 60 min/day moderate‑to‑vigorous; include bone/muscle‑strengthening 3×/week.\n• **Reduce sugary drinks and ultra‑processed foods**: Replace with water; choose minimally processed options.\n• **Regular schedule**: Consistent meal times; avoid late‑night overeating.\n• **Sleep & stress**: Adequate sleep improves appetite regulation; manage stress.\n• **Healthcare support**: Consider nutrition counseling and screening for comorbidities per clinician advice.\n\nReferences:\n[1] WHO. Obesity and overweight. Fact sheet. https://www.who.int/news-room/fact-sheets/detail/obesity-and-overweight\n[2] WHO. Physical activity guidelines (2020). https://www.who.int/publications/i/item/9789240015128\n[3] DOH/FNRI‑DOST. Pinggang Pinoy®. https://www.fnri.dost.gov.ph/"
            ],

            'adolescent_health': [
                "**WHO Physical Activity (Children & Adolescents 5–17 years)**\n\n• **Average ≥60 min/day** moderate‑to‑vigorous aerobic activity.\n• Include **vigorous‑intensity** and **muscle/bone‑strengthening** activities **≥3 days/week**.\n• Limit sedentary screen time; prioritize outdoor play when safe.\n\nReference: WHO 2020 Guidelines. https://www.who.int/publications/i/item/9789240015128",

                "**Nutrition (Philippines: Pinggang Pinoy® & Go‑Grow‑Glow)**\n\n• **Pinggang Pinoy®**: Half plate vegetables/fruits; quarter rice/whole grains; quarter protein (fish, eggs, chicken, legumes).\n• **Go‑Grow‑Glow**: \n  – Go (energy): rice, bread, root crops\n  – Grow (protein): fish, eggs, beans, lean meats\n  – Glow (vitamins/minerals): vegetables and fruits\n• Prefer water; limit sugar‑sweetened beverages.\n\nReferences: FNRI‑DOST / DOH resources. https://www.fnri.dost.gov.ph/",

                "**Sleep, Hydration, & Mental Well‑being**\n\n• **Sleep**: Teens typically need **8–10 hours** nightly; keep consistent schedules.\n• **Hydration**: Water as primary beverage; encourage regular intake during school and sports.\n• **Mental health**: Promote supportive environments; teach stress‑management (breathing exercises, physical activity, social support).\n• **Dental**: Brush 2×/day with fluoride toothpaste; limit sugary snacks/drinks.\n\nReferences: WHO adolescent health resources; DOH school health programs. https://www.who.int/health-topics/adolescent-health"
            ],

            'nutrition_basics': [
                "**Nutrition Basics:**\n\n• **Plate balance**: 1/2 vegetables, 1/4 protein, 1/4 whole grains\n• **Protein**: eggs, fish, chicken, tofu, legumes\n• **Carbs**: rice, oats, whole‑grain bread/pasta, potatoes\n• **Fats**: olive oil, avocado, nuts, seeds\n• **Hydration**: water most of the time; limit sugary drinks",
                
                "**Best Foods (General):**\n\n• **Proteins**: fish, chicken, eggs, beans, lentils\n• **Carbs**: rice, oats, quinoa, whole‑grain bread\n• **Fats**: olive oil, nuts, seeds\n• **Extras**: fruits and colorful vegetables daily"
            ],

            'calorie_guidance': [
                "**Calories (General Guidance):**\n\n• **Maintenance** varies by age, sex, size, and activity\n• Many adults maintain around **1800–2400 kcal/day** (wide range)\n• If you're active, needs are higher; if sedentary, lower\n• Focus on nutrient‑dense foods and consistent meals\n• For personal targets, use a calculator and consult a clinician",
                
                "**Is 2000 Calories OK?**\n\n• For many people, **~2000 kcal** is a common reference intake\n• It can be fine for some, too low/high for others\n• Consider activity level and goals (maintain/lose/gain)\n• Emphasize quality: protein at each meal, vegetables, whole grains, healthy fats"
            ],

            'identity': [
                "I'm a local healthcare guidance assistant designed to provide general education and best‑practice tips.",
                "I'm a local educational assistant focused on general wellness and nursing best practices."
            ]
        }
        
        logger.info("✅ Simple Healthcare AI initialized")
    
    def contains_phi(self, text):
        """PHI detection disabled per user request (always returns False)."""
        return False
    
    def generate_response(self, message):
        """Generate healthcare response based on keywords"""
        
        if self.contains_phi(message):
            return {
                "response": "⚠️ **HIPAA Compliance Alert**: Your message appears to contain protected health information (PHI). Please rephrase your question without including specific patient data, names, IDs, or personal health details.",
                "phi_detected": True,
                "tokens_used": 0
            }
        
        message_lower = message.lower()
        
        # Match keywords to responses
        if any(word in message_lower for word in ['hand', 'hygiene', 'wash', 'sanitize']):
            responses = self.healthcare_responses['hand_hygiene']
        elif any(word in message_lower for word in ['infection', 'control', 'ppe', 'isolation']):
            responses = self.healthcare_responses['infection_control']
        elif any(word in message_lower for word in ['document', 'record', 'chart', 'note']):
            responses = self.healthcare_responses['documentation']
        elif any(word in message_lower for word in ['safety', 'medication', 'fall', 'emergency']):
            responses = self.healthcare_responses['patient_safety']
        elif any(word in message_lower for word in ['wellness', 'health', 'nutrition', 'exercise']):
            responses = self.healthcare_responses['wellness']
        elif any(word in message_lower for word in [
            'underweight', 'overweight', 'obese', 'obesity', 'healthy weight', 'normal weight',
            'weight', 'gain weight', 'lose weight', 'bmi', 'body mass index',
            'lifestyle', 'diet', 'meal plan', 'exercise plan', 'workout', 'fitness'
        ]):
            responses = self.healthcare_responses['weight_management'] + self.healthcare_responses['adolescent_health']
        elif any(word in message_lower for word in ['food', 'foods', 'best food', 'nutrition', 'eat', 'healthy foods']):
            responses = self.healthcare_responses['nutrition_basics']
        elif any(word in message_lower for word in ['calorie', 'calories', 'kcal', '2000']):
            responses = self.healthcare_responses['calorie_guidance']
        elif any(word in message_lower for word in ['what ai', 'who are you', 'what are you']):
            responses = self.healthcare_responses['identity']
        else:
            # Default response
            responses = [
                "How can I help? You can ask about hand hygiene, infection control, patient safety, documentation tips, wellness, nutrition, exercise plans, or calorie guidance.",
                "What would you like to know about health, wellness, nutrition, exercise, patient safety, or documentation?"
            ]
        
        import random
        selected_response = random.choice(responses)
        
        return {
            "response": selected_response,
            "phi_detected": False,
            "tokens_used": len(message.split()) + len(selected_response.split()),
            "model": "simple-healthcare-ai"
        }

# Initialize AI
simple_ai = SimpleHealthcareAI()

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "model_loaded": True,
        "model": "simple-healthcare-ai",
        "timestamp": datetime.now().isoformat()
    })

def _cors_preflight_response():
    origin = request.headers.get('Origin', '*')
    resp = make_response('', 204)
    resp.headers['Access-Control-Allow-Origin'] = origin
    resp.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'
    resp.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, X-Requested-With, X-HIPAA-Compliant'
    resp.headers['Access-Control-Max-Age'] = '86400'
    # Chrome Private Network Access (PNA) preflight support
    if request.headers.get('Access-Control-Request-Private-Network') == 'true':
        resp.headers['Access-Control-Allow-Private-Network'] = 'true'
    resp.headers['Vary'] = 'Origin'
    return resp

@app.after_request
def _add_cors_headers(resp):
    try:
        origin = request.headers.get('Origin', '*')
        resp.headers['Access-Control-Allow-Origin'] = origin
        resp.headers.setdefault('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        resp.headers.setdefault('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With, X-HIPAA-Compliant')
        if request.headers.get('Access-Control-Request-Private-Network') == 'true':
            resp.headers['Access-Control-Allow-Private-Network'] = 'true'
        # Help caches differentiate per-origin
        prev_vary = resp.headers.get('Vary')
        resp.headers['Vary'] = ('Origin' if not prev_vary else (prev_vary + ', Origin'))
    except Exception:
        pass
    return resp

@app.route('/', methods=['GET', 'OPTIONS'])
def root_page():
    if request.method == 'OPTIONS':
        return _cors_preflight_response()
    return jsonify({"ok": True, "service": "simple-healthcare-ai"})

@app.route('/favicon.ico', methods=['GET', 'OPTIONS'])
def favicon():
    if request.method == 'OPTIONS':
        return _cors_preflight_response()
    # No favicon; avoid 404 noise
    return ('', 204)

# Wildcard OPTIONS handler so any preflight succeeds
@app.route('/<path:any_path>', methods=['OPTIONS'])
def any_options(any_path):
    return _cors_preflight_response()

@app.route('/chat/completions', methods=['POST', 'OPTIONS'])
def chat_completions():
    """OpenAI-compatible chat completions endpoint"""
    # CORS preflight
    if request.method == 'OPTIONS':
        return _cors_preflight_response()
    
    try:
        data = request.get_json()
        
        # Extract message from OpenAI format
        messages = data.get('messages', [])
        if not messages:
            return jsonify({"error": "No messages provided"}), 400
        
        # Get the last user message
        user_message = ""
        for msg in reversed(messages):
            if msg.get('role') == 'user':
                user_message = msg.get('content', '')
                break
        
        if not user_message:
            return jsonify({"error": "No user message found"}), 400
        
        # Generate response
        result = simple_ai.generate_response(user_message)
        
        # Log interaction
        logger.info(f"AI Request - Tokens: {result.get('tokens_used', 0)}, PHI: {result.get('phi_detected', False)}")
        
        # Return in OpenAI format
        response = jsonify({
            "choices": [{
                "message": {
                    "role": "assistant",
                    "content": result["response"]
                },
                "finish_reason": "stop"
            }],
            "usage": {
                "total_tokens": result.get("tokens_used", 0)
            },
            "model": result.get("model", "simple-healthcare-ai"),
            "phi_detected": result.get("phi_detected", False)
        })
        response.headers['Access-Control-Allow-Origin'] = '*'
        response.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, X-Requested-With, X-HIPAA-Compliant'
        return response
        
    except Exception as e:
        logger.error(f"Error in chat completion: {e}")
        return jsonify({
            "error": "Internal server error",
            "details": str(e)
        }), 500

@app.route('/api/admin/ai-assistant-log', methods=['POST', 'OPTIONS'])
def log_ai_interaction():
    """Log AI assistant interactions for HIPAA compliance"""
    # CORS preflight
    if request.method == 'OPTIONS':
        return _cors_preflight_response()
    try:
        log_data = request.get_json()
        log_data['server_timestamp'] = datetime.now().isoformat()
        
        # Log to file
        log_file = "ai_assistant_audit.log"
        with open(log_file, "a") as f:
            f.write(json.dumps(log_data) + "\n")
        
        logger.info(f"AI interaction logged: {log_data.get('eventType', 'unknown')}")
        return jsonify({"status": "logged"})
        
    except Exception as e:
        logger.error(f"Error logging AI interaction: {e}")
        return jsonify({"error": "Logging failed"}), 500

if __name__ == '__main__':
    print("""
🤖 ZENITH Health System - Simple AI Server
==========================================

Starting healthcare AI server (no authentication required)...

Features:
✅ No Hugging Face login needed
✅ HIPAA-compliant PHI detection
✅ Healthcare knowledge base
✅ Audit logging
✅ Local processing

Server will be available at: http://localhost:5000
Health check: http://localhost:5000/health
""")
    
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)
