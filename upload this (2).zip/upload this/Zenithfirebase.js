const { default: firebase } = require("firebase/compat/app");

const firebaseConfig = {
  apiKey: "AIzaSyBEk9UXDr4FMc1mjXJuAu8VqHY-A4DCbhc",
  authDomain: "zenith-software-2295d.firebaseapp.com",
  databaseURL: "https://zenith-software-2295d-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "zenith-software-2295d",
  storageBucket: "zenith-software-2295d.firebasestorage.app",
  messagingSenderId: "829496605819",
  appId: "1:829496605819:web:c6d620408941f8ab4276de",
  measurementId: "G-TL5WK3N5KN"
};


// initialize firebase
firebase.initializeApp(firebaseConfig);

// reference your database
firebase.database().ref()