// firebase-config.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-firestore.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-auth.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBEk9UXDr4FMc1mjXJuAu8VqHY-A4DCbhc",
  authDomain: "zenith-software-2295d.firebaseapp.com",
  databaseURL: "https://zenith-software-2295d-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "zenith-software-2295d",
  storageBucket: "zenith-software-2295d.firebasestorage.app",
  messagingSenderId: "829496605819",
  appId: "1:829496605819:web:0056e5913ef4125f4276de",
  measurementId: "G-QFNH9VHK8R"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// ✅ Export instances
export { app, db, auth };
