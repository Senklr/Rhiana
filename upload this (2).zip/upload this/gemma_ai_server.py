#!/usr/bin/env python3
"""
ZENITH Health System - Local Gemma 3 AI Server
Serves Gemma 3-270m model locally for HIPAA-compliant healthcare AI assistant
"""

import os
import json
import logging
from datetime import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
import torch
import re

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)  # Enable CORS for web app access

class GemmaHealthcareAI:
    def __init__(self):
        self.model = None
        self.tokenizer = None
        self.pipe = None
        # Prefer local model directory if available; otherwise use hub id (instruction-tuned)
        local_model_dir = os.path.join(os.path.dirname(__file__), "models", "gemma-3-270m-it")
        self.model_name = local_model_dir if os.path.isdir(local_model_dir) else "google/gemma-3-270m-it"
        self.max_length = 512
        self.temperature = 0.7
        
        # PHI detection patterns (same as frontend)
        self.phi_patterns = [
            r'\b\d{3}-\d{2}-\d{4}\b',  # SSN
            r'\b[A-Z]{2,3}-\d{3,6}\b',  # LRN
            r'\b\d{10,}\b',  # Phone numbers
            r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',  # Email
            r'\b\d+\s*(kg|lbs?|pounds?)\b',  # Weight
            r'\b\d+\s*(cm|ft|feet|inches?|in)\b',  # Height
            r'\bBMI\s*:?\s*\d+',  # BMI
            r'\b\d+\/\d+\s*mmHg\b',  # Blood pressure
            r'\b[A-Z][a-z]+\s+[A-Z][a-z]+\b',  # Full names
            r'\b(Mr|Mrs|Ms|Dr)\.?\s+[A-Z][a-z]+\b',  # Titles with names
        ]
        
        self.load_model()
    
    def load_model(self):
        """Load Gemma 3 model and tokenizer"""
        try:
            logger.info(f"Loading {self.model_name}...")
            
            # Read Hugging Face token from environment (do not hardcode secrets) when pulling from hub
            HF_TOKEN = os.getenv("HF_TOKEN") or os.getenv("HUGGINGFACEHUB_API_TOKEN")
            using_hub = "/" in self.model_name  # crude check: hub ids contain '/'
            if using_hub and not HF_TOKEN:
                raise RuntimeError(
                    "Hugging Face token not found. Set HF_TOKEN or HUGGINGFACEHUB_API_TOKEN in your environment, or download the model to 'models/gemma-3-270m-it' to load locally."
                )
            
            # Check if CUDA is available
            device = "cuda" if torch.cuda.is_available() else "cpu"
            logger.info(f"Using device: {device}")
            
            # Load tokenizer with token
            tok_kwargs = {"token": HF_TOKEN} if using_hub else {}
            self.tokenizer = AutoTokenizer.from_pretrained(
                self.model_name,
                **tok_kwargs
            )
            
            # Load model with token
            mdl_kwargs = {"token": HF_TOKEN} if using_hub else {}
            self.model = AutoModelForCausalLM.from_pretrained(
                self.model_name,
                torch_dtype=torch.float16 if device == "cuda" else torch.float32,
                device_map="auto" if device == "cuda" else None,
                **mdl_kwargs
            )
            
            # Create pipeline
            self.pipe = pipeline(
                "text-generation",
                model=self.model,
                tokenizer=self.tokenizer,
                device=0 if device == "cuda" else -1
            )
            
            logger.info("✅ Gemma 3 model loaded successfully!")
            
        except Exception as e:
            logger.error(f"❌ Error loading model: {e}")
            raise
    
    def contains_phi(self, text, allow_lrn: bool = False):
        """Check if text contains PHI patterns. When allow_lrn is True, permit LRN-style references
        such as "LRN 123456789012" by skipping long-number and LRN patterns if they are clearly
        tied to an LRN reference.
        """
        try:
            t = text or ""
            # If allow_lrn and the text explicitly references an LRN + long digits, relax those checks
            if allow_lrn:
                lrn_ref = re.search(r"lrn\s*[:\-\(]?\s*\d{7,20}", t, re.IGNORECASE)
            else:
                lrn_ref = None

            for pattern in self.phi_patterns:
                # Skip LRN pattern and long-number pattern when allow_lrn and an LRN reference is present
                if allow_lrn and lrn_ref:
                    if pattern == r'\b[A-Z]{2,3}-\d{3,6}\b' or pattern == r'\b\d{10,}\b':
                        continue
                if re.search(pattern, t, re.IGNORECASE):
                    return True
            return False
        except Exception:
            # Fail safe: if detection fails, do not block
            return False
    
    def generate_healthcare_response(self, user_message, allow_lrn: bool = False, disable_phi: bool = False, context: dict | None = None):
        """Generate healthcare-focused response"""
        
        # Check for PHI (unless explicitly disabled by client for development)
        if not disable_phi and self.contains_phi(user_message, allow_lrn=allow_lrn):
            return {
                "response": "⚠️ **HIPAA Compliance Alert**: Your message appears to contain protected health information (PHI). Please rephrase your question without including specific patient data, names, IDs, or personal health details.",
                "phi_detected": True,
                "tokens_used": 0
            }
        
        # Build optional context string
        ctx = ""
        try:
            if context and isinstance(context, dict):
                demo = context.get('demographics') or {}
                metr = context.get('metrics') or {}
                ctx_lines = ["Available Context (anonymized):"]
                if demo:
                    ctx_lines.append(f"- Demographics: age={demo.get('age')}, sex={demo.get('sex')}, grade={demo.get('grade')}, section={demo.get('section')}")
                if metr:
                    ctx_lines.append(f"- Metrics: weight={metr.get('weight')}kg, height={metr.get('height')}cm, BMI={metr.get('bmi')} ({metr.get('bmiCategory')}), bodyFat%={metr.get('bodyFatPercent')}, muscle%={metr.get('musclePercent')}")
                ctx = "\n" + "\n".join(ctx_lines)
        except Exception:
            ctx = ""

        # Healthcare-focused system prompt with structured plan requirements
        system_prompt = (
            "You are a healthcare education assistant. Provide general guidance only.\n"
            "Always be evidence-based (prioritize WHO, DOH).\n"
            "CRITICAL: Do not ask for more information. Always generate a best-effort plan now.\n"
            "If context is missing, assume a generally healthy adolescent/young adult and moderate intensity.\n"
            "Format requirements:\n"
            "1) Title line: 'One‑Week Exercise Plan (General Guidance)'.\n"
            "2) Brief tailoring note if age/sex/BMI context is provided.\n"
            "3) 7‑day schedule (Mon–Sun) with specific activities, duration, and intensity.\n"
            "4) Safety notes and progression tips (concise).\n"
            "5) References [1], [2] with organization, title, year, and URL.\n"
            "Avoid repeating generic disclaimers. Keep the response compact and practical. Return the plan directly without prefacing with instructions." 
            + ctx
        )

        # Combine system prompt with user message
        full_prompt = f"{system_prompt}\n\nNurse Question: {user_message}\n\nAI Response:"
        
        try:
            # Generate response
            outputs = self.pipe(
                full_prompt,
                max_new_tokens=600,
                temperature=self.temperature,
                do_sample=True,
                pad_token_id=self.tokenizer.eos_token_id,
                num_return_sequences=1,
                return_full_text=False,
                truncation=True,
                max_length=2048
            )
            
            # Extract response
            response_text = outputs[0]['generated_text'].strip()
            
            # Clean up response (remove any remaining prompt text)
            if "AI Response:" in response_text:
                response_text = response_text.split("AI Response:")[-1].strip()
            
            # Count tokens (approximate)
            tokens_used = len(full_prompt.split()) + len(response_text.split())
            
            return {
                "response": response_text,
                "phi_detected": False,
                "tokens_used": tokens_used,
                "model": self.model_name
            }
            
        except Exception as e:
            logger.error(f"Error generating response: {e}")
            return {
                "response": "I apologize, but I'm having trouble generating a response right now. Please try again later or contact technical support.",
                "phi_detected": False,
                "tokens_used": 0,
                "error": str(e)
            }

# Initialize AI model
try:
    gemma_ai = GemmaHealthcareAI()
except Exception as e:
    logger.error(f"Failed to initialize Gemma AI: {e}")
    gemma_ai = None

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy" if gemma_ai else "unhealthy",
        "model_loaded": gemma_ai is not None,
        "timestamp": datetime.now().isoformat()
    })

@app.route('/chat/completions', methods=['POST'])
def chat_completions():
    """OpenAI-compatible chat completions endpoint"""
    
    if not gemma_ai:
        return jsonify({
            "error": "AI model not loaded"
        }), 500
    
    try:
        data = request.get_json()
        
        # Extract message from OpenAI format
        messages = data.get('messages', [])
        if not messages:
            return jsonify({"error": "No messages provided"}), 400
        
        # Get the last user message
        user_message = ""
        for msg in reversed(messages):
            if msg.get('role') == 'user':
                user_message = msg.get('content', '')
                break
        
        if not user_message:
            return jsonify({"error": "No user message found"}), 400
        
        # Allow LRN when requested by client; permit completely disabling PHI in dev
        allow_lrn = bool(data.get('allow_lrn'))
        disable_phi = bool(data.get('disable_phi'))

        # Pass optional context from client
        context = data.get('context') if isinstance(data, dict) else None

        # Generate response
        result = gemma_ai.generate_healthcare_response(
            user_message,
            allow_lrn=allow_lrn,
            disable_phi=disable_phi,
            context=context
        )
        
        # Log interaction (without PHI)
        logger.info(f"AI Request - Tokens: {result.get('tokens_used', 0)}, PHI: {result.get('phi_detected', False)}")
        
        # Return in OpenAI format
        return jsonify({
            "choices": [{
                "message": {
                    "role": "assistant",
                    "content": result["response"]
                },
                "finish_reason": "stop"
            }],
            "usage": {
                "total_tokens": result.get("tokens_used", 0)
            },
            "model": result.get("model", "gemma-3-270m"),
            "phi_detected": result.get("phi_detected", False)
        })
        
    except Exception as e:
        logger.error(f"Error in chat completion: {e}")
        return jsonify({
            "error": "Internal server error",
            "details": str(e)
        }), 500

@app.route('/api/admin/ai-assistant-log', methods=['POST'])
def log_ai_interaction():
    """Log AI assistant interactions for HIPAA compliance"""
    try:
        log_data = request.get_json()
        
        # Add server timestamp
        log_data['server_timestamp'] = datetime.now().isoformat()
        
        # Log to file (in production, use proper logging service)
        log_file = "ai_assistant_audit.log"
        with open(log_file, "a") as f:
            f.write(json.dumps(log_data) + "\n")
        
        logger.info(f"AI interaction logged: {log_data.get('eventType', 'unknown')}")
        
        return jsonify({"status": "logged"})
        
    except Exception as e:
        logger.error(f"Error logging AI interaction: {e}")
        return jsonify({"error": "Logging failed"}), 500

if __name__ == '__main__':
    print("""
🤖 ZENITH Health System - Gemma 3 AI Server
===========================================

Starting local AI server with Gemma 3-270m...

Requirements:
- pip install transformers torch flask flask-cors
- Hugging Face account with access to Gemma 3
- GPU recommended (but CPU works)

Server will be available at: http://localhost:5000
Health check: http://localhost:5000/health

HIPAA Features:
✅ PHI detection and blocking
✅ Healthcare-focused prompts
✅ Audit logging
✅ Local processing (no external APIs)
""")
    
    # Run server
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=False,  # Set to False for production
        threaded=True
    )
