// ZENITH Health System - AI Configuration
// Configure real AI service for HIPAA-compliant healthcare assistant

// AI Configuration Options
window.ZENITH_AI_CONFIG = {
  enabled: true, // Enable real AI backend
  
  // Local server (private by design)
  provider: 'local-gemma',
  endpoint: 'http://127.0.0.1:5000/chat/completions',
  apiKey: 'local-server', // Not needed for local server
  model: 'gemma-3-270m',
  
  // Alternative: OpenAI API (ensure compliance and BAA if used in healthcare)
  // provider: 'openai',
  // endpoint: 'https://api.openai.com/v1/chat/completions',
  // apiKey: 'YOUR_OPENAI_API_KEY',
  // model: 'gpt-4o-mini',
  
  // Response controls (used by ai-assistant.js)
  // Prefer character-length enforcement; words kept for backward compatibility
  minChars: 1000, // enforce 1000+ characters
  minWords: 1000, // legacy; not used if minChars is present
  maxTokens: 2000, // allow long outputs
  temperature: 0.2, // lower for accuracy and stability
  preferredSources: [
    'World Health Organization (WHO)',
    'Philippine Department of Health (DOH)',
    'Centers for Disease Control and Prevention (CDC)',
    'UNICEF',
    'Peer-reviewed journals (The Lancet, NEJM, BMJ)'
  ],
  // Personalization & variety controls
  allowLRN: true, // allow the assistant to accept an LRN in the message and resolve anonymized metrics
  styles: {
    clinicalTone: 'clear, professional, stepwise reasoning',
    patientEducationTone: 'empathetic, actionable, plain language',
    diabetesFocus: true // hint: prefer diabetes-related considerations when relevant to metrics
  },
  enableLogging: true,
  
  // HIPAA compliance settings
  dataRetention: false, // Never retain conversation data
  auditLogging: true,   // Log non-PHI interaction metadata for compliance
  phiDetection: false   // Keep assistant general but not PHI-blocking at input layer
};

// Instructions for setup:
console.log(`
🤖 ZENITH AI Assistant Configuration

To enable real AI responses:

1. AZURE OPENAI (Recommended for HIPAA):
   - Sign up for Azure OpenAI Service
   - Create a resource and deployment
   - Get your endpoint and API key
   - Sign Business Associate Agreement (BAA)
   - Update ZENITH_AI_CONFIG above

2. OPENAI API (Less secure for healthcare):
   - Get API key from OpenAI
   - Update endpoint and apiKey
   - Note: May not be fully HIPAA compliant

3. AWS BEDROCK:
   - Set up AWS account with Bedrock access
   - Configure IAM credentials
   - Update endpoint and credentials

4. Enable the service:
   - Set enabled: true
   - Test with non-PHI questions first

Current status: ${window.ZENITH_AI_CONFIG.enabled ? '✅ ENABLED' : '❌ DISABLED (using fallback responses)'}
`);

// Validation function
function validateAIConfig() {
  const config = window.ZENITH_AI_CONFIG;
  
  if (!config.enabled) {
    return { valid: false, message: 'AI service disabled' };
  }
  
  if (!config.endpoint || config.endpoint.includes('YOUR_')) {
    return { valid: false, message: 'Invalid endpoint configuration' };
  }
  
  if (!config.apiKey || config.apiKey.includes('YOUR_')) {
    return { valid: false, message: 'Invalid API key configuration' };
  }
  
  return { valid: true, message: 'Configuration valid' };
}

// Test function
async function testAIConnection() {
  const validation = validateAIConfig();
  
  if (!validation.valid) {
    console.warn('⚠️ AI Config:', validation.message);
    return false;
  }
  
  try {
    const response = await fetch(window.ZENITH_AI_CONFIG.endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${window.ZENITH_AI_CONFIG.apiKey}`
      },
      body: JSON.stringify({
        model: window.ZENITH_AI_CONFIG.model,
        messages: [{ role: 'user', content: 'Test connection' }],
        max_tokens: 10
      })
    });
    
    if (response.ok) {
      console.log('✅ AI service connection successful');
      return true;
    } else {
      console.error('❌ AI service connection failed:', response.status);
      return false;
    }
  } catch (error) {
    console.error('❌ AI service test error:', error);
    return false;
  }
}

// Export for use in other modules
window.validateAIConfig = validateAIConfig;
window.testAIConnection = testAIConnection;
