# 🤖 ZENITH AI Assistant - Real AI Setup Guide

## Quick Setup Instructions

Your AI assistant is now ready for real AI integration! Here's how to make it smart:

### Option 1: Azure OpenAI (Recommended for Healthcare) ⭐

**Why Azure OpenAI?**
- ✅ HIPAA-compliant with Business Associate Agreement (BAA)
- ✅ Data stays in your Azure tenant (not used for training)
- ✅ Enterprise-grade security and compliance
- ✅ GPT-4 and GPT-3.5 Turbo available

**Setup Steps:**
1. **Sign up for Azure OpenAI Service**
   - Go to [Azure Portal](https://portal.azure.com)
   - Search for "Azure OpenAI"
   - Request access (may take 1-2 business days)

2. **Create Resource & Deployment**
   ```
   Resource Name: zenith-ai-service
   Region: East US (or your preferred region)
   Pricing Tier: Standard S0
   ```

3. **Deploy a Model**
   ```
   Model: gpt-4 or gpt-35-turbo
   Deployment Name: zenith-chat-model
   ```

4. **Get Your Credentials**
   - Copy your **Endpoint URL**
   - Copy your **API Key**

5. **Update Configuration**
   Open `ai-config.js` and update:
   ```javascript
   window.ZENITH_AI_CONFIG = {
     enabled: true, // Change this to true
     provider: 'azure-openai',
     endpoint: 'https://YOUR-RESOURCE.openai.azure.com/openai/deployments/YOUR-DEPLOYMENT/chat/completions?api-version=2024-02-15-preview',
     apiKey: 'YOUR_ACTUAL_API_KEY_HERE',
     model: 'gpt-4'
   };
   ```

### Option 2: OpenAI API (Easier but less HIPAA-compliant)

**Setup Steps:**
1. Go to [OpenAI Platform](https://platform.openai.com)
2. Create account and get API key
3. Update `ai-config.js`:
   ```javascript
   window.ZENITH_AI_CONFIG = {
     enabled: true,
     provider: 'openai',
     endpoint: 'https://api.openai.com/v1/chat/completions',
     apiKey: 'sk-your-openai-api-key-here',
     model: 'gpt-4'
   };
   ```

⚠️ **Note**: OpenAI's standard API may not be fully HIPAA-compliant for healthcare data.

### Option 3: AWS Bedrock (Advanced)

**Setup Steps:**
1. Set up AWS account with Bedrock access
2. Configure IAM credentials
3. Update configuration for Claude or other models

## 🔒 HIPAA Compliance Features

The AI assistant includes built-in HIPAA protection:

- **PHI Detection**: Automatically blocks patient information
- **Audit Logging**: All interactions logged for compliance
- **No Data Retention**: Conversations not stored by AI service
- **Secure Headers**: HIPAA-compliant request headers
- **Local Processing**: PHI filtering happens locally

## 🧪 Testing Your Setup

1. **Open the nurse dashboard**
2. **Click the AI assistant chat bubble** (bottom-right)
3. **Check the browser console** for connection status
4. **Test with a simple question**: "What are best practices for hand hygiene?"

## 💰 Cost Estimates

**Azure OpenAI:**
- GPT-4: ~$0.03 per 1K tokens (~750 words)
- GPT-3.5: ~$0.002 per 1K tokens
- Typical nurse query: $0.01-0.05 per interaction

**OpenAI API:**
- Similar pricing to Azure OpenAI
- Pay-per-use model

## 🛠️ Troubleshooting

**"AI service disabled" message:**
- Set `enabled: true` in `ai-config.js`

**"Invalid endpoint" error:**
- Replace placeholder URLs with your actual endpoints
- Remove "YOUR_" prefixes from configuration

**"API key invalid" error:**
- Check your API key is correct
- Ensure proper permissions in Azure/OpenAI

**Connection timeout:**
- Check internet connection
- Verify endpoint URL format
- Test API key with curl/Postman first

## 📞 Support

For technical assistance with AI setup:
- **Email**: dev@zenithhealth.com
- **Documentation**: This guide
- **Console Logs**: Check browser developer tools

---

**Current Status**: AI assistant is configured but disabled by default. Follow the setup steps above to enable real AI responses!
