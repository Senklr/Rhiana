# ZENITH Final System - Deployment & Testing Guide

## 🎯 Overview
The ZNTHFNALCODE.ino file successfully combines:
- **HC-SR04 Ultrasonic Sensor** - Height measurement
- **Xiaomi Mi Scale BLE Integration** - Weight and body composition  
- **Firebase Realtime Database** - Data storage
- **Web Server** - RESTful API endpoints for HTML integration
- **CORS Support** - Cross-origin resource sharing for web interfaces

## 📁 Files Overview

### Arduino Code
- **ZNTHFNALCODE.ino** - Combined ESP32 firmware with all sensors and web server
- **hc-sr04.ino** - Original ultrasonic sensor code (reference)
- **XIAOMISCALE.ino** - Original Xiaomi scale code (reference)

### Web Interface  
- **test-esp32.html** - Comprehensive test page for ESP32 functionality
- **student-info-form.html** - Updated to work with new JSON API
- **esp32-data-service.js** - Updated for new response format
- **firebase-config.js** - Firebase configuration
- **student-view.html** - Student dashboard
- **nurseview.html** - Nurse dashboard

## 🔧 Hardware Setup

### Required Components
1. **ESP32 Development Board**
2. **HC-SR04 Ultrasonic Sensor**
   - VCC → 5V or 3.3V
   - GND → GND  
   - Trig → GPIO 5
   - Echo → GPIO 18
3. **Xiaomi Mi Body Composition Scale 2**
   - MAC Address: `5C:CA:D3:98:01:48` (update in code if different)

### Wiring Diagram
```
ESP32          HC-SR04
GPIO 5    →    TRIG
GPIO 18   →    ECHO  
5V        →    VCC
GND       →    GND
```

## 🚀 Software Deployment

### 1. Arduino IDE Setup
1. Install ESP32 board support in Arduino IDE
2. Install required libraries:
   - `Firebase ESP32 Client` by Mobitz
   - `ArduinoJson` by Benoit Blanchon
   - `WiFi` (built-in)
   - `WebServer` (built-in)
   - `BLEDevice` (built-in)

### 2. Configuration
Update these values in `ZNTHFNALCODE.ino`:

```cpp
// WiFi Configuration
#define WIFI_SSID      "Your_WiFi_Network"
#define WIFI_PASSWORD  "Your_WiFi_Password"

// Firebase Configuration  
#define API_KEY        "Your_Firebase_API_Key"
#define DATABASE_URL   "Your_Firebase_Database_URL"
#define USER_EMAIL     "your_email@gmail.com"
#define USER_PASSWORD  "your_password"

// Scale Configuration (if different)
static BLEAddress scaleAddress("5C:CA:D3:98:01:48");

// Height Sensor Calibration
const float SENSOR_HEIGHT_CM = 200.0; // Distance from floor to sensor
```

### 3. Upload Firmware
1. Connect ESP32 to computer via USB
2. Select correct board and port in Arduino IDE
3. Upload `ZNTHFNALCODE.ino` to ESP32
4. Monitor Serial output for connection status

## 🧪 Testing

### 1. Basic Connection Test
Open `test-esp32.html` in a web browser to:
- ✅ Check ESP32 connection status
- ✅ Test WiFi, Firebase, and BLE connectivity
- ✅ Set student ID
- ✅ Retrieve sensor data
- ✅ Monitor real-time responses

### 2. System Integration Test
1. **Start ESP32** - Monitor serial output for successful initialization
2. **Check Connections** - Use test page to verify all systems online
3. **Set Student ID** - Use test page or student-info-form.html
4. **Height Test** - Stand under sensor, verify height readings
5. **Scale Test** - Step on scale, verify weight and body composition data
6. **Data Flow Test** - Confirm data reaches Firebase and HTML interface

### 3. Web Interface Test
1. **Registration** - Use `student-info-form.html`
2. **Data Collection** - Use `student-view.html`
3. **Nurse Dashboard** - Use `nurseview.html`

## 🌐 API Endpoints

The ESP32 provides these endpoints at `http://192.168.100.250`:

### GET /status
Returns system status and connectivity information:
```json
{
  "wifi_connected": true,
  "wifi_ip": "192.168.100.250",
  "firebase_ready": true,
  "ble_connected": true,
  "scale_address": "5c:ca:d3:98:01:48",
  "sensor_height_cm": 200.0,
  "current_student": "123456789012",
  "data_available": true,
  "status": "online"
}
```

### POST /setID
Sets the current student LRN for data association:
```json
// Request
{
  "studentLRN": "123456789012"
}

// Response
{
  "status": "success",
  "studentLRN": "123456789012"
}
```

### GET /getData
Returns latest sensor measurements:
```json
{
  "height_cm": 175.2,
  "weight_kg": 68.5,
  "bmi": 22.3,
  "bodyFat_pct": 15.8,
  "muscle_kg": 52.3,
  "water_pct": 58.9,
  "bone_kg": 3.2,
  "visceral": 8.5,
  "bmr_kcal": 1680,
  "impedance_ohm": 485.2,
  "timestamp_ms": 1692284847234,
  "studentLRN": "123456789012",
  "status": "success"
}
```

## 🔍 Troubleshooting

### Common Issues

1. **ESP32 Not Connecting to WiFi**
   - Check SSID and password in code
   - Verify network is 2.4GHz (ESP32 doesn't support 5GHz)
   - Check signal strength

2. **BLE Scale Connection Failed**
   - Verify scale MAC address
   - Ensure scale is powered on and in pairing mode
   - Check Bluetooth permissions

3. **Firebase Connection Issues**
   - Verify API key and database URL
   - Check Firebase authentication credentials
   - Ensure Firebase rules allow read/write access

4. **Sensor Reading Issues**
   - Check HC-SR04 wiring connections
   - Verify sensor height calibration
   - Test sensor individually

5. **Web Interface CORS Errors**
   - Serve HTML files from web server (not file://)
   - Check browser console for specific errors

### Debug Steps

1. **Serial Monitor** - Check ESP32 startup messages
2. **Test Page** - Use `test-esp32.html` for comprehensive diagnostics
3. **Network Tools** - Use ping/curl to test ESP32 connectivity
4. **Firebase Console** - Monitor database for incoming data

## 📊 System Operation Flow

1. **Initialization**
   - ESP32 connects to WiFi
   - Firebase authentication
   - BLE connection to scale
   - Web server starts

2. **Student Registration**
   - Student enters info via web form
   - Data sent to Firestore
   - Student LRN sent to ESP32

3. **Measurement Process**
   - Student steps on scale
   - HC-SR04 measures height
   - Scale sends weight/impedance via BLE
   - Body composition calculated
   - Data uploaded to Firebase

4. **Data Access**
   - Web interfaces retrieve data via ESP32 API
   - Nurses access data via dashboard
   - Students view their measurements

## ✅ Success Indicators

- ✅ ESP32 serial shows "System ready!"
- ✅ Test page shows all systems online
- ✅ Student can register and set ID
- ✅ Height and weight measurements appear
- ✅ Data appears in Firebase console
- ✅ Web interfaces display measurements correctly

## 🎯 Next Steps

1. **Calibration** - Fine-tune sensor height and scale readings
2. **User Training** - Train nurses and students on system usage  
3. **Production Setup** - Deploy to actual environment
4. **Monitoring** - Set up logging and alerting systems
5. **Backup** - Implement data backup procedures

## 🔧 Maintenance

- **Monthly**: Check sensor calibration
- **Weekly**: Monitor Firebase usage and costs
- **Daily**: Check system status via test page
- **As Needed**: Update student profiles and system settings

---

🎉 **System Successfully Integrated!** 
The ZENITH health monitoring system is now ready for deployment with combined HC-SR04 height measurement and Xiaomi scale integration, all connected to your web interface through a unified ESP32 system.
