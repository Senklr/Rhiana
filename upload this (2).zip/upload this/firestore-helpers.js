// firestore-helpers.js
// Reusable Firestore helpers for Zenith front-ends
// Uses the centralized app/db/auth from firebase-config.js (ESM v11+)

import { db, auth } from './firebase-config.js';
import {
  doc,
  getDoc,
  getDocs,
  setDoc,
  collection,
  onSnapshot,
  serverTimestamp,
  query,
  orderBy,
  limit
} from 'https://www.gstatic.com/firebasejs/11.4.0/firebase-firestore.js';

// getStudentData(lrn) → fetch specific student data once.
export async function getStudentData(lrn) {
  if (!lrn) throw new Error('getStudentData: lrn is required');
  const ref = doc(db, 'students', String(lrn));
  const snap = await getDoc(ref);
  return snap.exists() ? { id: snap.id, ...snap.data() } : null;
}

// listenStudentData(lrn, callback) → live updates for a student.
export function listenStudentData(lrn, callback) {
  if (!lrn) throw new Error('listenStudentData: lrn is required');
  const ref = doc(db, 'students', String(lrn));
  const unsub = onSnapshot(ref, (snap) => {
    callback(snap.exists() ? { id: snap.id, ...snap.data() } : null);
  });
  return unsub;
}

// getAllStudents() → fetch all student documents (basic list for nurse view)
export async function getAllStudents() {
  const ref = collection(db, 'students');
  const qs = await getDocs(ref);
  const items = [];
  qs.forEach((d) => items.push({ id: d.id, ...d.data() }));
  return items;
}

// listenAllStudents(callback) → realtime list of all students
// callback receives an array: [{ id, ...data }, ...]
export function listenAllStudents(callback) {
  const ref = collection(db, 'students');
  const unsub = onSnapshot(ref, (snap) => {
    const items = [];
    snap.forEach((d) => items.push({ id: d.id, ...d.data() }));
    callback(items);
  });
  return unsub;
}

// Optional: get recent history entries for a student (if needed by UI)
export async function getRecentHistory(lrn, max = 10) {
  const ref = collection(db, 'students', String(lrn), 'history');
  const qs = await getDocs(query(ref, orderBy('timestamp', 'desc'), limit(max)));
  const items = [];
  qs.forEach((d) => items.push({ id: d.id, ...d.data() }));
  return items;
}

// Web-only helper to upsert latestReading (NOT used by ESP32)
export async function upsertLatestReading(lrn, { weight, height, bmi }) {
  const ref = doc(db, 'students', String(lrn));
  const latestReading = {
    weight: Number.isFinite(weight) ? Number(weight) : null,
    height: Number.isFinite(height) ? Number(height) : null,
    bmi: Number.isFinite(bmi) ? Number(bmi) : null,
    timestamp: serverTimestamp(),
  };
  await setDoc(ref, { latestReading }, { merge: true });
}
