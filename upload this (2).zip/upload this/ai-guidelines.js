// ai-guidelines.js
// Structured, citeable snippets distilled from JSAI.txt for composing safe prompts.
// Exposes window.ZenithGuidelines

(function(){
  const WHO = {
    adults: {
      aerobic: "150–300 minutes/week moderate OR 75–150 minutes/week vigorous OR equivalent mix",
      strength: "Muscle-strengthening 2+ days/week",
      sedentary: "Reduce sedentary time; replace with activity when possible"
    },
    olderAdults: {
      balance: "Include balance/coordination work 3+ days/week to reduce falls"
    },
    youth: {
      duration: "Average 60 minutes/day moderate-to-vigorous across the week",
      vigorous: "Vigorous + muscle/bone-strengthening 3+ days/week"
    },
    nutrition: {
      variety: "Varied diet emphasizing fruits, vegetables, legumes, nuts, whole grains",
      sugar: "Limit free sugars <10% total energy (ideally <5%)",
      salt: "Keep salt <5 g/day",
      fats: "Prefer unsaturated fats over saturated/trans fats",
      water: "Choose safe water; avoid sugar-sweetened beverages"
    }
  };

  const CDC = {
    aerobic: "≥150 min/week moderate OR 75 min/week vigorous; spread across the week",
    strength: "Muscle-strengthening ≥2 days/week",
    flexibilityBalance: "Balance/flexibility especially for older adults"
  };

  const DGA_US = {
    sugars: "Added sugars <10% of calories/day",
    sodium: "Sodium <2,300 mg/day for adults",
    alcohol: "If consumed: ≤1 drink/day women, ≤2 drinks/day men",
    plate: "Half plate fruits/vegetables; include whole grains and lean proteins"
  };

  const PH = {
    bmiCutoffs: "PH (Asian) BMI thresholds: Normal 18.5–<23; Overweight ≥23; Obesity ≥25",
    nncActivity: "Adults: 150 min moderate or 75 min vigorous weekly; Strength ≥2 days/week",
  };

  // Helper to produce a compact, evidence-based plan outline
  function makeWeeklyExercisePlan({age, sex, bmiCategory}){
    const lines = [];
    lines.push("Evidence-based one-week exercise plan (WHO/CDC-aligned):");
    lines.push("- Aerobic: 30 min x 5 days (moderate) OR 25–30 min x 3 days (vigorous) OR a mix");
    lines.push("- Strength: 2 days (full-body: legs, push, pull, core)");
    if (age >= 65) lines.push("- Balance/coordination: 3 sessions (e.g., single-leg stands, tai chi)");
    lines.push("- Optional flexibility 10 min after sessions");
    lines.push("");
    lines.push("Mon: Brisk walk 30 min (or cycling), light core (10 min)");
    lines.push("Tue: Strength 30–40 min (squats/lunges, push-ups, rows, planks)");
    lines.push("Wed: Brisk walk/jog 30 min");
    lines.push("Thu: Strength 30–40 min (full-body variations)");
    lines.push("Fri: Brisk walk 30 min or swim 20–25 min (vigorous)");
    lines.push("Sat: Optional light activity 20–30 min (mobility/yoga)");
    lines.push("Sun: Rest or light walk 15–20 min");

    const notes = [];
    notes.push("Notes (not medical advice):");
    notes.push("- Start easy, progress gradually; stop with pain or warning symptoms");
    notes.push("- Hydrate and prioritize sleep (7–9h adults)");
    notes.push("- If BMI ≥23 (PH cutoffs) or new to exercise, favor moderate intensity initially");
    if (age >= 65) notes.push("- Include balance drills; consider supervision when needed");

    return lines.concat([""], notes).join("\n");
  }

  window.ZenithGuidelines = {
    WHO, CDC, DGA_US, PH,
    makeWeeklyExercisePlan
  };
})();
