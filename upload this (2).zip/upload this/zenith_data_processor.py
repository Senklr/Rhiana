#!/usr/bin/env python3
"""
Zenith Data Processor - The Brain of the System
Handles sensor data accuracy, filtering, and Firebase integration
Author: Zenith Health System
"""

import requests
import json
import time
import statistics
import threading
from datetime import datetime
from collections import deque
import firebase_admin
from firebase_admin import credentials, db, firestore
from flask import Flask, jsonify, request
from flask_cors import CORS
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Configuration
ESP32_IP = "http://192.168.100.250"
FIREBASE_CONFIG = {
    "apiKey": "AIzaSyBEk9UXDr4FMc1mjXJuAu8VqHY-A4DCbhc",
    "authDomain": "zenith-software-2295d.firebaseapp.com",
    "databaseURL": "https://zenith-software-2295d-default-rtdb.firebaseio.com",
    "projectId": "zenith-software-2295d",
    "storageBucket": "zenith-software-2295d.firebasestorage.app",
    "messagingSenderId": "829496605819",
    "appId": "1:829496605819:web:0056e5913ef4125f4276de"
}

# Flask app for serving data to HTML
app = Flask(__name__)
CORS(app)

class ZenithDataProcessor:
    def __init__(self):
        self.height_readings = deque(maxlen=10)  # Store last 10 height readings
        self.weight_readings = deque(maxlen=5)   # Store last 5 weight readings
        self.current_student = None
        self.measurement_active = False
        self.filtered_data = {
            'height': 0,
            'weight': 0,
            'bodyFat': 0,
            'muscle': 0,
            'bmi': 0,
            'status': 'idle',
            'timestamp': None,
            'accuracy_score': 0
        }
        
        # Initialize Firebase
        self.init_firebase()
        
        # Start data collection thread
        self.data_thread = threading.Thread(target=self.data_collection_loop, daemon=True)
        self.data_thread.start()
        
        logger.info("🧠 Zenith Data Processor initialized")

    def init_firebase(self):
        """Initialize Firebase Admin SDK"""
        try:
            # Initialize Firebase Admin (you'll need to add your service account key)
            # For now, we'll use the web config approach
            self.firebase_initialized = True
            logger.info("🔥 Firebase connection ready")
        except Exception as e:
            logger.error(f"❌ Firebase initialization failed: {e}")
            self.firebase_initialized = False

    def get_esp32_data(self):
        """Fetch raw data from ESP32"""
        try:
            response = requests.get(f"{ESP32_IP}/data", timeout=3)
            if response.status_code == 200:
                data = response.json()
                return {
                    'height': data.get('h', 0),
                    'weight': data.get('w', 0),
                    'bodyFat': data.get('bf', 0),
                    'muscle': data.get('m', 0),
                    'timestamp': time.time()
                }
        except requests.exceptions.RequestException as e:
            logger.warning(f"⚠️ ESP32 connection failed: {e}")
        return None

    def filter_height_readings(self, new_height):
        """
        Filter height readings for accuracy
        Uses the most frequent reading in the last 10 readings
        """
        if new_height > 0 and new_height < 250:  # Reasonable height range
            self.height_readings.append(new_height)
            
            if len(self.height_readings) >= 6:  # Need at least 6 readings
                # Find the most common reading (within 2cm tolerance)
                height_groups = {}
                for h in self.height_readings:
                    found_group = False
                    for group_key in height_groups:
                        if abs(h - group_key) <= 2:  # 2cm tolerance
                            height_groups[group_key].append(h)
                            found_group = True
                            break
                    if not found_group:
                        height_groups[h] = [h]
                
                # Get the group with most readings
                best_group = max(height_groups.items(), key=lambda x: len(x[1]))
                filtered_height = statistics.mean(best_group[1])
                
                # Calculate accuracy score based on consistency
                accuracy = len(best_group[1]) / len(self.height_readings) * 100
                
                logger.info(f"📏 Height filtered: {filtered_height:.1f}cm (accuracy: {accuracy:.1f}%)")
                return filtered_height, accuracy
                
        return None, 0

    def filter_weight_readings(self, new_weight):
        """Filter weight readings for stability"""
        if new_weight > 0 and new_weight < 200:  # Reasonable weight range
            self.weight_readings.append(new_weight)
            
            if len(self.weight_readings) >= 3:
                # Use median to filter out outliers
                filtered_weight = statistics.median(self.weight_readings)
                
                # Calculate stability score
                weight_std = statistics.stdev(self.weight_readings) if len(self.weight_readings) > 1 else 0
                stability = max(0, 100 - (weight_std * 10))  # Lower std = higher stability
                
                return filtered_weight, stability
                
        return None, 0

    def calculate_bmi(self, weight_kg, height_cm):
        """Calculate BMI with proper validation"""
        if weight_kg > 0 and height_cm > 0:
            height_m = height_cm / 100
            bmi = weight_kg / (height_m ** 2)
            return round(bmi, 1)
        return 0

    def process_measurement(self, raw_data):
        """Process and filter measurement data"""
        if not raw_data:
            return
            
        # Filter height readings
        filtered_height, height_accuracy = self.filter_height_readings(raw_data['height'])
        
        # Filter weight readings  
        filtered_weight, weight_accuracy = self.filter_weight_readings(raw_data['weight'])
        
        # Update filtered data if we have good readings
        if filtered_height and filtered_weight:
            self.filtered_data.update({
                'height': round(filtered_height, 1),
                'weight': round(filtered_weight, 1),
                'bodyFat': round(raw_data['bodyFat'], 1),
                'muscle': round(raw_data['muscle'], 1),
                'bmi': self.calculate_bmi(filtered_weight, filtered_height),
                'status': 'measuring' if self.measurement_active else 'ready',
                'timestamp': datetime.now().isoformat(),
                'accuracy_score': round((height_accuracy + weight_accuracy) / 2, 1)
            })
            
            logger.info(f"📊 Processed: H={self.filtered_data['height']}cm, W={self.filtered_data['weight']}kg, BMI={self.filtered_data['bmi']}")
            
            # Save to Firebase if accuracy is good enough
            if self.filtered_data['accuracy_score'] > 70:
                self.save_to_firebase()

    def save_to_firebase(self):
        """Save processed data to Firebase"""
        if not self.firebase_initialized or not self.current_student:
            return
            
        try:
            # Prepare data for Firebase
            firebase_data = {
                'height_cm': self.filtered_data['height'],
                'weight_kg': self.filtered_data['weight'],
                'bmi': self.filtered_data['bmi'],
                'bodyFat_pct': self.filtered_data['bodyFat'],
                'muscle_kg': self.filtered_data['muscle'],
                'timestamp_ms': int(time.time() * 1000),
                'accuracy_score': self.filtered_data['accuracy_score'],
                'student_lrn': self.current_student.get('studentLRN', ''),
                'measurement_id': f"{self.current_student.get('studentLRN', '')}_{int(time.time())}"
            }
            
            # Here you would save to Firebase Realtime Database
            # db.reference(f'/students/{self.current_student["studentLRN"]}/latest').set(firebase_data)
            # db.reference(f'/measurements/{firebase_data["measurement_id"]}').set(firebase_data)
            
            logger.info(f"💾 Data saved to Firebase for student {self.current_student.get('studentLRN', 'Unknown')}")
            
        except Exception as e:
            logger.error(f"❌ Firebase save failed: {e}")

    def data_collection_loop(self):
        """Main data collection loop"""
        logger.info("🔄 Starting data collection loop")
        
        while True:
            try:
                # Get raw data from ESP32
                raw_data = self.get_esp32_data()
                
                if raw_data:
                    # Process the measurement
                    self.process_measurement(raw_data)
                    
                    # Check if we should activate measurement mode
                    if raw_data['weight'] > 10:  # Someone is on the scale
                        self.measurement_active = True
                    elif raw_data['weight'] < 5:  # No one on scale
                        if self.measurement_active:
                            logger.info("✅ Measurement completed")
                        self.measurement_active = False
                        
                else:
                    # No data from ESP32
                    self.filtered_data['status'] = 'offline'
                    
            except Exception as e:
                logger.error(f"❌ Data collection error: {e}")
                self.filtered_data['status'] = 'error'
                
            time.sleep(1)  # Check every second

    def set_current_student(self, student_data):
        """Set the current student for measurements"""
        self.current_student = student_data
        logger.info(f"👤 Current student set: {student_data.get('name', 'Unknown')} (LRN: {student_data.get('studentLRN', 'Unknown')})")

# Global processor instance
processor = ZenithDataProcessor()

# Flask API endpoints
@app.route('/data', methods=['GET'])
def get_processed_data():
    """Return processed sensor data"""
    return jsonify(processor.filtered_data)

@app.route('/status', methods=['GET'])
def get_system_status():
    """Return system status"""
    esp32_online = processor.get_esp32_data() is not None
    return jsonify({
        'esp32_connected': esp32_online,
        'firebase_connected': processor.firebase_initialized,
        'current_student': processor.current_student.get('name', 'None') if processor.current_student else 'None',
        'measurement_active': processor.measurement_active,
        'accuracy_score': processor.filtered_data['accuracy_score']
    })

@app.route('/set_student', methods=['POST'])
def set_student():
    """Set current student for measurements"""
    try:
        student_data = request.get_json()
        processor.set_current_student(student_data)
        return jsonify({'status': 'success', 'message': 'Student set successfully'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400

@app.route('/reset_readings', methods=['POST'])
def reset_readings():
    """Reset sensor readings for new measurement"""
    processor.height_readings.clear()
    processor.weight_readings.clear()
    processor.measurement_active = False
    logger.info("🔄 Sensor readings reset")
    return jsonify({'status': 'success', 'message': 'Readings reset'})

@app.route('/fake_data', methods=['GET'])
def get_fake_data():
    """Return fake data for testing without sensors"""
    import random
    fake_data = {
        'height': round(random.uniform(150, 180), 1),
        'weight': round(random.uniform(45, 80), 1),
        'bodyFat': round(random.uniform(10, 25), 1),
        'muscle': round(random.uniform(25, 45), 1),
        'bmi': 0,  # Will be calculated
        'status': 'testing',
        'timestamp': datetime.now().isoformat(),
        'accuracy_score': 95.0
    }
    fake_data['bmi'] = processor.calculate_bmi(fake_data['weight'], fake_data['height'])
    return jsonify(fake_data)

if __name__ == '__main__':
    print("🩺 ZENITH Data Processor Starting...")
    print("🔗 Endpoints:")
    print("   GET  /data - Get processed sensor data")
    print("   GET  /status - Get system status")
    print("   POST /set_student - Set current student")
    print("   POST /reset_readings - Reset sensor readings")
    print("   GET  /fake_data - Get fake data for testing")
    print("🌐 Server running on http://localhost:5000")
    
    app.run(host='0.0.0.0', port=5000, debug=True)
