// ZENITH Health System - HIPAA-Compliant AI Assistant
// Provides healthcare guidance while protecting PHI

// Define the class only once to prevent "Identifier has already been declared" on live reloads or duplicate script tags
if (typeof window !== 'undefined' && !window.ZenithAIAssistant) {
  window.ZenithAIAssistant = class ZenithAIAssistant {
  constructor() {
    this.isActive = false;
    this.conversationHistory = [];
    this.sessionId = this.generateSessionId();
    this.listenersAttached = false; // guard against duplicate listeners
    this._lastToggleTs = 0; // debounce toggle
    this.phiPatterns = [
      // Strong identifiers only
      /\b\d{3}-\d{2}-\d{4}\b/,                 // SSN-like
      /\b[A-Z]{2,3}-\d{3,6}\b/,                 // LRN/code pattern (e.g., AB-12345)
      /\b\d{10,}\b/,                            // Long numeric IDs/phones (10+ digits)
      /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/, // Email
    ];
    
    this.allowedTopics = [
      'general health education',
      'wellness tips',
      'exercise recommendations',
      'nutrition guidelines',
      'stress management',
      'sleep hygiene',
      'preventive care',
      'health screening guidelines',
      'first aid procedures',
      'infection control',
      'documentation best practices',
      'nursing procedures',
      'patient safety protocols'
    ];
    
    this.init();
  }

  // Extract LRN from message text. Accept patterns like "lrn(123...)" or plain 11-14 digit numbers.
  extractLRN(text = '') {
    try {
      const lower = String(text).toLowerCase();
      const inParen = lower.match(/lrn\s*[(:\-]?\s*(\d{7,20})/i);
      if (inParen && inParen[1]) return inParen[1];
      const longNum = lower.match(/\b(\d{11,20})\b/);
      return longNum ? longNum[1] : null;
    } catch { return null; }
  }

  // Resolve anonymized context from the UI (table) via a page-provided hook
  async resolveContext(message = '') {
    try {
      const lrn = this.extractLRN(message);
      if (!lrn) return null;
      if (typeof window.resolveLRNForAI === 'function') {
        const result = await window.resolveLRNForAI(lrn);
        if (result && (result.metrics || result.demographics)) {
          return {
            idHint: `lrn_${String(lrn).slice(-4)}`,
            demographics: result.demographics || {},
            metrics: result.metrics || {}
          };
        }
      }
      return null;
    } catch {
      return null;
    }
  }

  init() {
    this.createAssistantUI();
    this.setupEventListeners();
    console.log('🤖 HIPAA-compliant AI Assistant initialized');
    try {
      const cfg = window.ZENITH_AI_CONFIG || {};
      if (cfg.autoOpen === true) {
        // Slight delay to ensure DOM nodes are present
        setTimeout(() => { try { this.show(); } catch {} }, 50);
      }
    } catch {}
  }

  generateSessionId() {
    return 'ai_session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }

  createAssistantUI() {
    // Avoid duplicating the UI if it already exists
    if (document.getElementById('ai-assistant')) return;
    const assistantHTML = `
      <div id="ai-assistant" class="ai-assistant">
        <div class="ai-header">
          <div class="ai-title">
            <span class="ai-icon">🤖</span>
            <span>ZENITH AI Assistant</span>
            <span class="hipaa-badge">HIPAA Safe</span>
          </div>
          <button id="ai-toggle" class="ai-toggle" type="button">💬</button>
        </div>
        
        <div id="ai-chat" class="ai-chat" style="display: none;">
          <div class="ai-disclaimer">
            <div class="disclaimer-content">
              <span class="warning-icon">⚠️</span>
              <div>
                <strong>HIPAA Compliance Notice:</strong><br>
                Do not share any patient names, IDs, specific health data, or personal information. 
                This assistant provides general healthcare guidance only.
              </div>
            </div>
          </div>
          
          <div id="ai-messages" class="ai-messages">
            <div class="ai-message ai-message-bot">
              <div class="message-content">
                <span class="bot-icon">🩺</span>
                <div>
                  Hello! I'm your HIPAA-compliant healthcare assistant. I can help with:
                  <ul>
                    <li>General health education and wellness tips</li>
                    <li>Nursing procedures and best practices</li>
                    <li>Documentation guidelines</li>
                    <li>Patient safety protocols</li>
                  </ul>
                  <strong>Remember:</strong> Never share specific patient information or PHI.
                </div>
              </div>
            </div>
          </div>
          
          <div class="ai-input-section">
            <div class="ai-input-container">
              <input 
                type="text" 
                id="ai-input" 
                placeholder="Ask about general healthcare topics (no patient info)..."
                maxlength="500"
              >
              <button id="ai-send" class="ai-send-btn" type="button">
                <span class="send-icon">📤</span>
              </button>
            </div>
            <div class="ai-suggestions">
              <button class="suggestion-btn" data-suggestion="What are best practices for patient documentation?">📝 Documentation</button>
              <button class="suggestion-btn" data-suggestion="How can I promote student wellness?">💪 Wellness Tips</button>
              <button class="suggestion-btn" data-suggestion="What are infection control protocols?">🦠 Infection Control</button>
            </div>
          </div>
        </div>
      </div>
    `;

    // Add CSS styles
    const styles = `
      <style>
        .ai-assistant {
          position: fixed;
          bottom: 20px;
          right: 20px;
          width: 400px;
          max-width: 90vw;
          background: #1e293b;
          border-radius: 15px;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
          z-index: 2147483647; /* ensure on top of headers/modals */
          pointer-events: auto;
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          color: #e2e8f0;
        }

        .ai-header {
          background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
          color: white;
          padding: 15px 20px;
          border-radius: 15px 15px 0 0;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .ai-title {
          display: flex;
          align-items: center;
          gap: 10px;
          font-weight: 600;
        }

        .hipaa-badge {
          background: rgba(255, 255, 255, 0.2);
          padding: 2px 8px;
          border-radius: 12px;
          font-size: 0.75rem;
          font-weight: 500;
        }

        .ai-toggle {
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          padding: 8px 12px;
          border-radius: 8px;
          cursor: pointer;
          font-size: 1rem;
          transition: all 0.3s ease;
        }

        .ai-toggle:hover {
          background: rgba(255, 255, 255, 0.3);
          transform: scale(1.05);
        }

        .ai-chat {
          max-height: 500px;
          display: flex;
          flex-direction: column;
        }

        .ai-disclaimer {
          background: #fef3c7;
          border: 1px solid #f59e0b;
          margin: 15px;
          border-radius: 8px;
          padding: 12px;
        }

        .disclaimer-content {
          display: flex;
          gap: 10px;
          font-size: 0.85rem;
          color: #92400e;
        }

        .ai-messages {
          flex: 1;
          padding: 0 15px;
          max-height: 300px;
          overflow-y: auto;
          margin-bottom: 15px;
          background: #0f172a;
          border-radius: 8px;
          margin: 15px;
        }

        .ai-message {
          margin-bottom: 15px;
        }

        .ai-message-bot .message-content {
          background: #334155;
          color: #e2e8f0;
          border-radius: 15px 15px 15px 5px;
        }

        .ai-message-user .message-content {
          background: #6366f1;
          color: white;
          border-radius: 15px 15px 5px 15px;
          margin-left: 50px;
        }

        .message-content {
          padding: 12px 15px;
          display: flex;
          gap: 10px;
          align-items: flex-start;
        }

        .message-content ul {
          margin: 8px 0;
          padding-left: 20px;
        }

        .message-content li {
          margin-bottom: 4px;
        }

        .ai-input-section {
          padding: 15px;
          border-top: 1px solid #475569;
          background: #1e293b;
        }

        .ai-input-container {
          display: flex;
          gap: 10px;
          margin-bottom: 10px;
        }

        #ai-input {
          flex: 1;
          padding: 10px 15px;
          border: 2px solid #475569;
          border-radius: 25px;
          outline: none;
          font-size: 0.9rem;
          background: #0f172a;
          color: #e2e8f0;
          pointer-events: auto;
        }

        #ai-input:focus {
          border-color: #6366f1;
        }

        #ai-input::placeholder {
          color: #94a3b8;
        }

        .ai-send-btn {
          background: #6366f1;
          color: white;
          border: none;
          padding: 10px 15px;
          border-radius: 50%;
          cursor: pointer;
          transition: all 0.3s ease;
          pointer-events: auto;
        }

        .ai-send-btn:hover {
          background: #4f46e5;
          transform: scale(1.05);
        }

        .ai-suggestions {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
        }

        .suggestion-btn {
          background: #334155;
          border: 1px solid #475569;
          padding: 6px 12px;
          border-radius: 15px;
          font-size: 0.8rem;
          cursor: pointer;
          transition: all 0.3s ease;
          color: #e2e8f0;
        }

        .suggestion-btn:hover {
          background: #6366f1;
          color: white;
          border-color: #6366f1;
        }

        .typing-indicator {
          display: flex;
          align-items: center;
          gap: 5px;
          padding: 10px 15px;
          color: #6b7280;
          font-style: italic;
        }

        .typing-dots {
          display: flex;
          gap: 2px;
        }

        .typing-dot {
          width: 4px;
          height: 4px;
          background: #6b7280;
          border-radius: 50%;
          animation: typing 1.4s infinite;
        }

        .typing-dot:nth-child(2) { animation-delay: 0.2s; }
        .typing-dot:nth-child(3) { animation-delay: 0.4s; }

        @keyframes typing {
          0%, 60%, 100% { transform: translateY(0); opacity: 0.4; }
          30% { transform: translateY(-10px); opacity: 1; }
        }

        @media (max-width: 768px) {
          .ai-assistant {
            width: 95vw;
            bottom: 10px;
            right: 2.5vw;
          }
        }
      </style>
    `;

    // Add styles to head
    document.head.insertAdjacentHTML('beforeend', styles);
    
    // Add assistant to body
    document.body.insertAdjacentHTML('beforeend', assistantHTML);
  }

  setupEventListeners() {
    // idempotent: avoid attaching multiple times
    if (this.listenersAttached) return;
    const toggle = document.getElementById('ai-toggle');
    const chat = document.getElementById('ai-chat');
    const input = document.getElementById('ai-input');
    const sendBtn = document.getElementById('ai-send');
    const suggestions = document.querySelectorAll('.suggestion-btn');

    // Capture-phase listeners to block bubbling to any outer forms/handlers
    const assistantRoot = document.getElementById('ai-assistant');
    if (assistantRoot) {
      assistantRoot.addEventListener('click', (e) => {
        // prevent anchor navigation; allow buttons to perform their click handlers
        const tag = (e.target.tagName || '').toLowerCase();
        if (tag === 'a') {
          e.preventDefault();
        }
        // Do NOT stop propagation here so target click handlers still fire
      }, true);
      assistantRoot.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          const tag = (e.target.tagName || '').toLowerCase();
          const isTyping = tag === 'input' || tag === 'textarea';
          if (!isTyping) {
            e.preventDefault();
          }
          e.stopPropagation();
        }
      }, true);
      assistantRoot.addEventListener('submit', (e) => {
        e.preventDefault();
        e.stopPropagation();
      }, true);
    }

    if (toggle) toggle.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      try { console.log('[AI Assistant] Toggle clicked'); } catch {}
      const now = Date.now();
      if (now - this._lastToggleTs < 300) return; // debounce rapid double clicks
      this._lastToggleTs = now;
      const isVisible = chat.style.display !== 'none';
      chat.style.display = isVisible ? 'none' : 'block';
      toggle.textContent = isVisible ? '💬' : '✕';
      
      if (!isVisible) {
        this.logAIEvent('chat_opened');
      }
    });

    sendBtn.addEventListener('click', (e) => { 
      e.preventDefault(); 
      e.stopPropagation(); 
      try { console.log('[AI Assistant] Send clicked'); } catch {}
      this.sendMessage(); 
    });
    
    input.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        e.stopPropagation();
        try { console.log('[AI Assistant] Enter pressed'); } catch {}
        this.sendMessage();
      }
    });

    suggestions.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const suggestion = btn.dataset.suggestion;
        input.value = suggestion;
        this.sendMessage();
      });
    });

    // Prevent form submissions originating inside the AI assistant from reloading the page
    document.addEventListener('submit', (e) => {
      try {
        const assistant = document.getElementById('ai-assistant');
        if (assistant && assistant.contains(e.target)) {
          e.preventDefault();
        }
      } catch {}
    }, true);

    // Global toggle helper and hotkey (Alt + A)
    window.zenithAIToggle = () => {
      try {
        const panel = document.getElementById('ai-chat');
        const tgl = document.getElementById('ai-toggle');
        if (!panel || !tgl) return;
        const isVisible = panel.style.display !== 'none';
        panel.style.display = isVisible ? 'none' : 'block';
        tgl.textContent = isVisible ? '💬' : '✕';
        if (!isVisible) this.logAIEvent('chat_opened');
      } catch {}
    };
    document.addEventListener('keydown', (e) => {
      if (e.altKey && (e.key?.toLowerCase?.() === 'a')) {
        e.preventDefault();
        e.stopPropagation();
        window.zenithAIToggle();
      }
    });

    this.listenersAttached = true;
  }

  async sendMessage() {
    const input = document.getElementById('ai-input');
    const message = input.value.trim();
    
    if (!message) return;

    // Check for PHI before processing
    if (this.containsPHI(message)) {
      this.addMessage("⚠️ Please avoid sharing protected health information (PHI). Rephrase your question without names, IDs, or personal details.", 'bot');
      return;
    }

    // Attempt to extract LRN and attach anonymized context from the table
    let context = null;
    try {
      const lrnMatch = message.match(/lrn\s*[:\-]?\s*(\d{7,20})/i) || message.match(/\b(\d{11,20})\b/);
      const lrn = lrnMatch ? (lrnMatch[1] || lrnMatch[0]) : null;
      if (lrn && typeof window.resolveLRNForAI === 'function') {
        const clean = String(lrn).replace(/\D/g, '');
        context = await window.resolveLRNForAI(clean);
      }
    } catch {}

    // Add user message to chat
    this.addMessage(message, 'user');
    input.value = '';

    // Log the interaction
    this.logAIEvent('message_sent', { message: this.sanitizeForLogging(message) });

    // Show typing indicator
    this.showTypingIndicator();

    // Generate AI response
    try {
      const response = await this.generateResponse(message);
      this.hideTypingIndicator();
      this.addMessage(response, 'bot');
      
      this.logAIEvent('response_generated', { 
        response: this.sanitizeForLogging(response) 
      });
    } catch (error) {
      this.hideTypingIndicator();
      this.addMessage('I apologize, but I\'m having trouble responding right now. Please try again later or contact technical support.', 'bot');
      
      this.logAIEvent('response_error', { error: error.message });
    }
  }

  containsPHI(text) {
    try {
      if (window.ZENITH_AI_CONFIG && window.ZENITH_AI_CONFIG.phiDetection === false) {
        return false;
      }
      // Allow explicit LRN usage if configured and resolvable
      try {
        const cfg = window.ZENITH_AI_CONFIG || {};
        if (cfg.allowLRN && this.extractLRN(text)) {
          return false;
        }
      } catch {}
    } catch {}
    return this.phiPatterns.some(pattern => pattern.test(text));
  }

  showPHIWarning() {
    this.addMessage(
      '⚠️ **HIPAA Compliance Alert**: Your message appears to contain protected health information (PHI). Please rephrase your question without including specific patient data, names, IDs, or personal health details.',
      'bot'
    );
    
    this.logAIEvent('phi_blocked', { 
      message: 'PHI detected and blocked from processing' 
    });
  }

  addMessage(content, sender) {
    const messagesContainer = document.getElementById('ai-messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `ai-message ai-message-${sender}`;
    
    const icon = sender === 'bot' ? '🩺' : '👤';
    
    messageDiv.innerHTML = `
      <div class="message-content">
        <span class="${sender === 'bot' ? 'bot-icon' : 'user-icon'}">${icon}</span>
        <div>${this.formatMessage(content)}</div>
      </div>
    `;
    
    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
    
    // Store in conversation history (sanitized)
    this.conversationHistory.push({
      sender,
      content: this.sanitizeForLogging(content),
      timestamp: new Date().toISOString()
    });
  }

  formatMessage(content) {
    // Convert markdown-style formatting
    return content
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/\n/g, '<br>');
  }

  showTypingIndicator() {
    const messagesContainer = document.getElementById('ai-messages');
    const typingDiv = document.createElement('div');
    typingDiv.id = 'typing-indicator';
    typingDiv.className = 'typing-indicator';
    typingDiv.innerHTML = `
      <span>🩺</span>
      <span>AI is thinking</span>
      <div class="typing-dots">
        <div class="typing-dot"></div>
        <div class="typing-dot"></div>
        <div class="typing-dot"></div>
      </div>
    `;
    
    messagesContainer.appendChild(typingDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }

  hideTypingIndicator() {
    const indicator = document.getElementById('typing-indicator');
    if (indicator) {
      indicator.remove();
    }
  }

  async generateResponse(message) {
    // Try to resolve patient context (LRN -> metrics) without exposing identifiers
    let context = null;
    try {
      context = await this.resolveContext(message);
    } catch {}

    // Check if real AI is configured
    if (window.ZENITH_AI_CONFIG && window.ZENITH_AI_CONFIG.enabled) {
      return await this.callRealAI(message, context);
    }
    
    // Fallback to rule-based responses
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
    const responses = this.getContextualResponse(message.toLowerCase());
    return responses[Math.floor(Math.random() * responses.length)];
  }

  async callRealAI(message, context) {
    try {
      const config = window.ZENITH_AI_CONFIG;
      
      // Prepare the system prompt for healthcare context
      const minChars = Number(config?.minChars) || 1000;
      const preferredSources = config?.preferredSources || ['World Health Organization (WHO)', 'Philippine Department of Health (DOH)', 'Centers for Disease Control and Prevention (CDC)', 'UNICEF', 'UpToDate (summarized, no paywalled quotes)'];
      const systemPrompt = `You are a HIPAA-compliant healthcare AI assistant for nurses.

CRITICAL RULES:
- Never process or respond to any Protected Health Information (PHI)
- Only provide general healthcare education and nursing guidance
- If asked about specific patients, remind user about HIPAA compliance
- Focus on evidence-based healthcare practices
- Keep responses professional, accurate, and evidence-backed
- Always remind users to consult facility policies and supervisors

RESPONSE REQUIREMENTS:
- Start with a brief, direct answer to the question.
- Provide a comprehensive explanation that is at least ${minChars}+ characters in length (long-form answer).
- Use authoritative, up-to-date sources. Prioritize: ${preferredSources.join(', ')}.
- Include inline bracketed citations like [1], [2] that map to a References section at the end.
- Each reference must include organization, title, year (or “updated YYYY”), and a valid URL.
- If Philippine context is relevant, include DOH policies/programs and local epidemiology when available.
- Do not fabricate citations or statistics. If you are not certain, clearly state uncertainty and provide the best available guidance.

STYLE FOR VARIETY & CLINICAL PRECISION:
- Use clear clinical reasoning with stepwise planning (assessment → interventions → follow-up).
- Where applicable (e.g., diabetes), tailor education to metrics provided while keeping it non-diagnostic.
- Offer alternatives and red flags; be specific yet avoid prescribing or diagnosing.

You can help with:
- General health education and wellness
- Nursing procedures and best practices
- Documentation guidelines
- Patient safety protocols
- Infection control measures
- Professional development

Question: ${message}

Available Context (anonymized, optional): ${context ? JSON.stringify({
  patient: {
    id_hint: context.idHint || 'anon',
    demographics: context.demographics || {},
    metrics: context.metrics || {}
  }
}) : 'none'}`;

      // Build headers; avoid Authorization for local provider to reduce CORS preflight
      const headers = {
        'Content-Type': 'application/json',
        'X-HIPAA-Compliant': 'true'
      };
      try {
        const prov = (config.provider || '').toLowerCase();
        if (prov && prov !== 'local-gemma' && config.apiKey) {
          headers['Authorization'] = `Bearer ${config.apiKey}`;
        }
      } catch {}

      const response = await fetch(config.endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          model: config.model || 'gpt-4',
          messages: [
            {
              role: 'system',
              content: systemPrompt
            },
            {
              role: 'user', 
              content: message
            }
          ],
          allow_lrn: !!config.allowLRN,
          disable_phi: true,
          context: context || null,
          max_tokens: Math.min(Number(config?.maxTokens) || 2000, 4000),
          temperature: (typeof config?.temperature === 'number' ? config.temperature : 0.2),
          top_p: 0.9,
          presence_penalty: 0,
          frequency_penalty: 0
        })
      });

      if (!response.ok) {
        throw new Error(`AI service error: ${response.status}`);
      }

      const data = await response.json();
      
      // Log successful AI interaction
      this.logAIEvent('real_ai_response', {
        model: config.model,
        tokens_used: data.usage?.total_tokens || 'unknown'
      });

      let content = data.choices?.[0]?.message?.content || '';

      // Enforce minimum length and citations via a secondary expansion pass if needed
      content = await this.ensureLengthAndCitations(message, content, { minChars });
      return content;
      
    } catch (error) {
      console.error('Real AI service error:', error);
      
      this.logAIEvent('real_ai_error', { 
        error: error.message 
      });
      
      // Fallback to rule-based response
      const responses = this.getContextualResponse(message.toLowerCase());
      return `I'm having trouble connecting to the AI service right now. Here's some general guidance:\n\n${responses[0]}`;
    }
  }

  // Ensure response character length and add more citations if needed
  async ensureLengthAndCitations(originalQuestion, content, { minChars = 1000 } = {}) {
    try {
      const charCount = this.countChars(content);
      const hasReferences = /References\s*:|^\s*References\s*$/im.test(content) || /\n\[\d+\]/.test(content);
      if (charCount >= minChars && hasReferences) return content;

      const cfg = window.ZENITH_AI_CONFIG;
      if (!cfg?.endpoint || !cfg?.apiKey) return content; // cannot expand without AI

      const expandPrompt = `Expand and strengthen the response to be at least ${minChars}+ characters, adding more evidence and Philippine DOH/WHO context where applicable. Ensure inline citations [1], [2], etc., and a References section with titles, organizations, years, and valid URLs. Avoid any fabricated data. Question: ${originalQuestion}. Draft to improve:\n\n${content}`;

      const headers2 = {
        'Content-Type': 'application/json',
        'X-HIPAA-Compliant': 'true'
      };
      try {
        const prov2 = (cfg.provider || '').toLowerCase();
        if (prov2 && prov2 !== 'local-gemma' && cfg.apiKey) {
          headers2['Authorization'] = `Bearer ${cfg.apiKey}`;
        }
      } catch {}
      const response = await fetch(cfg.endpoint, {
        method: 'POST',
        headers: headers2,
        body: JSON.stringify({
          model: cfg.model || 'gpt-4',
          messages: [
            { role: 'system', content: 'You improve healthcare explanations with rigorous sourcing and DOH/WHO citations. Do not invent citations.' },
            { role: 'user', content: expandPrompt }
          ],
          max_tokens: Math.min(Number(cfg?.maxTokens) || 2200, 4000),
          temperature: (typeof cfg?.temperature === 'number' ? cfg.temperature : 0.2),
          top_p: 0.9
        })
      });

      if (!response.ok) return content;
      const data = await response.json();
      const improved = data.choices?.[0]?.message?.content || content;
      return improved;
    } catch {
      return content;
    }
  }

  countChars(text = '') {
    return String(text).length;
  }

  getContextualResponse(message) {
    if (message.includes('documentation') || message.includes('document')) {
      return [
        'For patient documentation best practices:\n\n• **Be Objective**: Record only factual observations\n• **Use Standard Terminology**: Follow medical terminology guidelines\n• **Document Timely**: Record information as soon as possible\n• **Include Relevant Details**: Time, date, and your signature\n• **Avoid Assumptions**: Only document what you directly observe\n\nRemember to follow your facility\'s specific documentation policies.',
        
        'Effective nursing documentation should be:\n\n• **Accurate and Complete**: Include all relevant patient interactions\n• **Legible**: Whether handwritten or electronic\n• **Chronological**: Document events in the order they occurred\n• **Professional**: Use appropriate medical language\n• **Confidential**: Ensure HIPAA compliance in all records'
      ];
    }
    
    if (message.includes('wellness') || message.includes('health promotion')) {
      return [
        'Student wellness promotion strategies:\n\n• **Regular Health Screenings**: Encourage routine check-ups\n• **Nutrition Education**: Promote balanced eating habits\n• **Physical Activity**: Support regular exercise routines\n• **Mental Health Awareness**: Provide stress management resources\n• **Sleep Hygiene**: Educate about healthy sleep patterns\n• **Preventive Care**: Emphasize vaccination and health maintenance',
        
        'Key wellness areas to focus on:\n\n• **Physical Health**: Regular exercise, proper nutrition, adequate sleep\n• **Mental Health**: Stress management, emotional support, counseling resources\n• **Social Health**: Encourage healthy relationships and community involvement\n• **Academic Balance**: Help students manage study stress\n• **Preventive Care**: Regular health screenings and immunizations'
      ];
    }
    
    if (message.includes('infection') || message.includes('control') || message.includes('safety')) {
      return [
        'Infection control protocols include:\n\n• **Hand Hygiene**: Proper handwashing technique and frequency\n• **Personal Protective Equipment**: Appropriate use of gloves, masks, gowns\n• **Environmental Cleaning**: Regular disinfection of surfaces and equipment\n• **Isolation Precautions**: When and how to implement isolation measures\n• **Waste Management**: Proper disposal of contaminated materials\n• **Staff Education**: Regular training on infection prevention',
        
        'Patient safety priorities:\n\n• **Medication Safety**: Verify patient identity and medication accuracy\n• **Fall Prevention**: Assess risk factors and implement preventive measures\n• **Communication**: Clear, effective communication among healthcare team\n• **Emergency Procedures**: Know location of emergency equipment and protocols\n• **Incident Reporting**: Report safety concerns promptly and accurately'
      ];
    }
    
    // Default responses for general queries
    return [
      'I\'m here to help with general healthcare guidance and nursing best practices. Could you be more specific about what you\'d like to know? Remember, I can\'t provide advice about specific patients or personal health information.',
      
      'I can assist with topics like:\n\n• General health education and wellness\n• Nursing procedures and protocols\n• Documentation guidelines\n• Patient safety practices\n• Infection control measures\n• Professional development\n\nWhat specific area would you like to explore?',
      
      'For the most accurate and up-to-date information, please consult your facility\'s policies, medical literature, or speak with your supervisor. I\'m here to provide general guidance and support your professional practice.'
    ];
  }

  sanitizeForLogging(text) {
    // Remove any potential PHI before logging
    let sanitized = text;
    
    this.phiPatterns.forEach(pattern => {
      sanitized = sanitized.replace(pattern, '[REDACTED]');
    });
    
    return sanitized;
  }

  logAIEvent(eventType, data = {}) {
    const logEntry = {
      timestamp: new Date().toISOString(),
      sessionId: this.sessionId,
      eventType,
      userAgent: navigator.userAgent,
      ...data
    };
    
    // Log to console for development
    console.log('🤖 AI Assistant Event:', logEntry);
    
    // In production, send to HIPAA-compliant logging service
    try {
      const cfg = window.ZENITH_AI_CONFIG || {};
      // Skip network logging in local mode to avoid console noise
      const provider = (cfg.provider || '').toLowerCase();
      if (provider === 'local-gemma') return;
      let logUrl = '/api/admin/ai-assistant-log';
      try {
        if (cfg.endpoint) {
          const u = new URL(cfg.endpoint);
          logUrl = `${u.origin}/api/admin/ai-assistant-log`;
        }
      } catch {}
      // Best-effort logging; ignore failures
      fetch(logUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(logEntry)
      }).catch(() => {});
    } catch {}
  }

  // Public methods for external control
  show() {
    const chat = document.getElementById('ai-chat');
    const toggle = document.getElementById('ai-toggle');
    if (!chat || !toggle) return;
    chat.style.display = 'block';
    toggle.textContent = '✕';
  }

  hide() {
    document.getElementById('ai-chat').style.display = 'none';
    document.getElementById('ai-toggle').textContent = '💬';
  }

  clearConversation() {
    document.getElementById('ai-messages').innerHTML = `
      <div class="ai-message ai-message-bot">
        <div class="message-content">
          <span class="bot-icon">🩺</span>
          <div>
            Hello! I'm your HIPAA-compliant healthcare assistant. How can I help you today?
            <br><br>
            <strong>Remember:</strong> Never share specific patient information or PHI.
          </div>
        </div>
      </div>
    `;
    this.conversationHistory = [];
    this.logAIEvent('conversation_cleared');
  }
}

// Close the one-time class definition guard
}

// Initialize AI Assistant robustly (works even if script loads after DOMContentLoaded)
(function initZenithAI() {
  function doInit() {
    try {
      const Ctor = window.ZenithAIAssistant;
      if (!Ctor) return; // class not available yet
      if (!window.zenithAI && (window.location.pathname.includes('nurseview.html') || true)) {
        window.zenithAI = new Ctor();
      }
    } catch (e) {
      try {
        const Ctor = window.ZenithAIAssistant;
        if (Ctor && !window.zenithAI) window.zenithAI = new Ctor();
      } catch {}
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', doInit, { once: true });
  } else {
    // DOM already ready
    doInit();
  }
})();

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ZenithAIAssistant;
}
