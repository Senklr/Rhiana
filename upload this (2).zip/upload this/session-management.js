// ZENITH Health System - HIPAA Compliant Session Management
// Handles secure login, session timeout, and data protection

class ZenithSessionManager {
  constructor() {
    this.sessionTimeout = 15 * 60 * 1000; // 15 minutes
    this.warningTime = 2 * 60 * 1000; // 2 minutes before timeout
    this.sessionTimer = null;
    this.warningTimer = null;
    this.isWarningShown = false;
    
    this.init();
  }

  init() {
    // Start session monitoring if user is authenticated
    if (this.isAuthenticated()) {
      this.startSessionMonitoring();
    }

    // Listen for user activity
    this.setupActivityListeners();
    
    // Check for existing consent
    this.checkUserConsent();
    
    console.log('🔒 HIPAA Session Management initialized');
  }

  // Check if user has given consent
  checkUserConsent() {
    const consent = localStorage.getItem('zenith-consent');
    if (!consent && this.requiresConsent()) {
      this.redirectToConsent();
      return false;
    }
    return true;
  }

  requiresConsent() {
    // Pages that require consent
    const consentRequiredPages = [
      'student-view.html',
      'nurseview.html',
      'student-info-form.html'
    ];
    
    return consentRequiredPages.some(page => 
      window.location.pathname.includes(page)
    );
  }

  redirectToConsent() {
    console.log('🔒 Redirecting to consent page');
    window.location.href = 'user-consent.html';
  }

  // Check if user is authenticated (Firebase Auth)
  isAuthenticated() {
    // This would integrate with your Firebase Auth
    // For now, check if we're on an authenticated page
    const authenticatedPages = [
      'student-view.html',
      'nurseview.html'
    ];
    
    return authenticatedPages.some(page => 
      window.location.pathname.includes(page)
    );
  }

  // Start monitoring user session
  startSessionMonitoring() {
    this.resetSessionTimer();
    console.log('⏱️ Session monitoring started (15min timeout)');
  }

  // Reset session timer on user activity
  resetSessionTimer() {
    // Clear existing timers
    if (this.sessionTimer) clearTimeout(this.sessionTimer);
    if (this.warningTimer) clearTimeout(this.warningTimer);
    
    this.isWarningShown = false;
    this.hideSessionWarning();

    // Set warning timer (2 minutes before timeout)
    this.warningTimer = setTimeout(() => {
      this.showSessionWarning();
    }, this.sessionTimeout - this.warningTime);

    // Set session timeout timer
    this.sessionTimer = setTimeout(() => {
      this.handleSessionTimeout();
    }, this.sessionTimeout);
  }

  // Setup activity listeners to reset timer
  setupActivityListeners() {
    const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click'];
    
    events.forEach(event => {
      document.addEventListener(event, () => {
        if (this.isAuthenticated()) {
          this.resetSessionTimer();
        }
      }, { passive: true });
    });
  }

  // Show session timeout warning
  showSessionWarning() {
    if (this.isWarningShown) return;
    
    this.isWarningShown = true;
    
    const warningDiv = document.createElement('div');
    warningDiv.id = 'session-warning';
    warningDiv.innerHTML = `
      <div style="
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: center;
      ">
        <div style="
          background: white;
          padding: 30px;
          border-radius: 15px;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
          text-align: center;
          max-width: 400px;
          margin: 20px;
        ">
          <div style="font-size: 3rem; margin-bottom: 15px;">⏰</div>
          <h3 style="color: #dc2626; margin-bottom: 15px;">Session Timeout Warning</h3>
          <p style="color: #6b7280; margin-bottom: 25px; line-height: 1.5;">
            Your session will expire in <strong>2 minutes</strong> for security purposes. 
            Click "Stay Logged In" to continue.
          </p>
          <div style="display: flex; gap: 15px; justify-content: center;">
            <button id="extend-session" style="
              background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
              color: white;
              border: none;
              padding: 12px 24px;
              border-radius: 8px;
              font-weight: 600;
              cursor: pointer;
            ">Stay Logged In</button>
            <button id="logout-now" style="
              background: #f3f4f6;
              color: #374151;
              border: 2px solid #d1d5db;
              padding: 12px 24px;
              border-radius: 8px;
              font-weight: 600;
              cursor: pointer;
            ">Logout Now</button>
          </div>
        </div>
      </div>
    `;
    
    document.body.appendChild(warningDiv);
    
    // Handle button clicks
    document.getElementById('extend-session').addEventListener('click', () => {
      this.extendSession();
    });
    
    document.getElementById('logout-now').addEventListener('click', () => {
      this.handleSessionTimeout();
    });
    
    console.log('⚠️ Session timeout warning shown');
  }

  // Hide session warning
  hideSessionWarning() {
    const warning = document.getElementById('session-warning');
    if (warning) {
      warning.remove();
    }
  }

  // Extend session when user clicks "Stay Logged In"
  extendSession() {
    this.hideSessionWarning();
    this.resetSessionTimer();
    
    // Log session extension for HIPAA compliance
    this.logSecurityEvent('session_extended');
    
    console.log('✅ Session extended');
  }

  // Handle session timeout
  handleSessionTimeout() {
    console.log('🔒 Session timed out - clearing data and redirecting');
    
    // Clear all sensitive data
    this.clearSensitiveData();
    
    // Log timeout event
    this.logSecurityEvent('session_timeout');
    
    // Show timeout message
    this.showTimeoutMessage();
    
    // Redirect to login after delay
    setTimeout(() => {
      window.location.href = 'index.html';
    }, 3000);
  }

  // Clear all sensitive data from browser
  clearSensitiveData() {
    // Clear localStorage of PHI
    const sensitiveKeys = [
      'studentData',
      'healthRecords',
      'personalInfo',
      'medicalData',
      'authToken',
      'sessionData'
    ];
    
    sensitiveKeys.forEach(key => {
      if (localStorage.getItem(key)) {
        localStorage.removeItem(key);
        console.log(`🗑️ Cleared ${key} from localStorage`);
      }
    });
    
    // Clear sessionStorage
    sessionStorage.clear();
    
    // Clear any cached form data
    const forms = document.querySelectorAll('form');
    forms.forEach(form => form.reset());
    
    console.log('🧹 All sensitive data cleared');
  }

  // Show timeout message
  showTimeoutMessage() {
    const timeoutDiv = document.createElement('div');
    timeoutDiv.innerHTML = `
      <div style="
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.9);
        z-index: 10001;
        display: flex;
        align-items: center;
        justify-content: center;
      ">
        <div style="
          background: white;
          padding: 40px;
          border-radius: 15px;
          text-align: center;
          max-width: 400px;
          margin: 20px;
        ">
          <div style="font-size: 4rem; margin-bottom: 20px;">🔒</div>
          <h3 style="color: #dc2626; margin-bottom: 15px;">Session Expired</h3>
          <p style="color: #6b7280; margin-bottom: 20px;">
            Your session has expired for security purposes. 
            All sensitive data has been cleared.
          </p>
          <p style="color: #6b7280; font-size: 0.9rem;">
            Redirecting to login page...
          </p>
        </div>
      </div>
    `;
    
    document.body.appendChild(timeoutDiv);
  }

  // Log security events for HIPAA compliance
  logSecurityEvent(eventType) {
    const logData = {
      timestamp: new Date().toISOString(),
      event: eventType,
      userAgent: navigator.userAgent,
      page: window.location.pathname,
      sessionId: this.getSessionId()
    };
    
    try {
      fetch('/api/admin/security-log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(logData)
      }).catch(error => {
        console.warn('⚠️ Could not log security event:', error);
      });
    } catch (error) {
      console.warn('⚠️ Security logging unavailable');
    }
    
    console.log(`📋 Security event logged: ${eventType}`);
  }

  // Get or generate session ID
  getSessionId() {
    let sessionId = sessionStorage.getItem('zenith-session-id');
    if (!sessionId) {
      sessionId = 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
      sessionStorage.setItem('zenith-session-id', sessionId);
    }
    return sessionId;
  }

  // Manual logout function
  logout() {
    console.log('🔒 Manual logout initiated');
    this.logSecurityEvent('manual_logout');
    this.clearSensitiveData();
    window.location.href = 'index.html';
  }

  // Data minimization - only collect essential data
  validateDataCollection(data) {
    const allowedFields = [
      'name', 'lrn', 'age', 'sex', 
      'weight', 'height', 'bmi', 
      'bodyFat', 'muscleMass'
    ];
    
    const filteredData = {};
    allowedFields.forEach(field => {
      if (data[field] !== undefined) {
        filteredData[field] = data[field];
      }
    });
    
    console.log('🔍 Data minimization applied');
    return filteredData;
  }

  // Check if user has required permissions
  hasPermission(action) {
    const userRole = this.getUserRole();
    
    const permissions = {
      'view_student_data': ['nurse', 'admin'],
      'edit_student_data': ['nurse', 'admin'],
      'view_own_data': ['student', 'nurse', 'admin'],
      'export_data': ['student', 'nurse', 'admin'],
      'delete_data': ['student', 'admin']
    };
    
    return permissions[action]?.includes(userRole) || false;
  }

  // Get user role from current page context
  getUserRole() {
    if (window.location.pathname.includes('student-view')) return 'student';
    if (window.location.pathname.includes('nurseview')) return 'nurse';
    if (window.location.pathname.includes('admin')) return 'admin';
    return 'guest';
  }
}

// Initialize session manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  window.zenithSession = new ZenithSessionManager();
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ZenithSessionManager;
}
