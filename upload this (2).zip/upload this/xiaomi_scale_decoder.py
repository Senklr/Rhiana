#!/usr/bin/env python3
"""
Xiaomi Mi Scale BLE Data Decoder
Based on https://github.com/lolouk44/xiaomi_mi_scale
Receives raw BLE data from ESP32 and decodes Xiaomi scale measurements
"""

import socket
import json
import struct
import time
import threading
import requests
from datetime import datetime
import firebase_admin
from firebase_admin import credentials, firestore
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Firebase configuration
FIREBASE_CONFIG = {
    "apiKey": "AIzaSyBEk9UXDr4FMc1mjXJuAu8VqHY-A4DCbhc",
    "authDomain": "zenith-software-2295d.firebaseapp.com",
    "databaseURL": "https://zenith-software-2295d-default-rtdb.asia-southeast1.firebasedatabase.app",
    "projectId": "zenith-software-2295d",
    "storageBucket": "zenith-software-2295d.firebasestorage.app",
    "messagingSenderId": "829496605819",
    "appId": "1:829496605819:web:0056e5913ef4125f4276de"
}

class XiaomiScaleDecoder:
    def __init__(self):
        self.server_socket = None
        self.latest_data = {
            "weight": 0,
            "height": 0,
            "bmi": 0,
            "muscle_mass": 0,
            "body_fat": 0,
            "timestamp": None,
            "status": "waiting"
        }
        self.current_student_id = None
        
        # 8-second averaging buffers
        self.weight_readings = []
        self.height_readings = []
        self.reading_start_time = None
        self.is_collecting = False
        
        # Credential processor connection
        self.credential_processor_url = "http://localhost:5001"
        
        # Initialize Firebase
        try:
            if not firebase_admin._apps:
                # Try to use service account file if it exists
                try:
                    cred = credentials.Certificate("zenith-software-2295d-firebase-adminsdk-fbsvc-28f21134ea.json")
                    firebase_admin.initialize_app(cred, {
                        'databaseURL': FIREBASE_CONFIG['databaseURL']
                    })
                except FileNotFoundError:
                    # Skip Firebase for now - will run in offline mode
                    raise Exception("Firebase credentials not configured")
            
            from firebase_admin import db
            self.db = db
            self.firebase_initialized = True
            logger.info("🔥 Firebase connection ready")
        except Exception as e:
            logger.error(f"❌ Firebase initialization failed: {e}")
            logger.info("📝 Running without Firebase - data will only be available via API")
            self.firebase_initialized = False
            self.db = None
    
    def decode_xiaomi_data(self, hex_data, height_cm=None):
        """
        Decode Xiaomi Mi Scale BLE data and add to averaging buffer
        Based on https://github.com/lolouk44/xiaomi_mi_scale
        Supports both MIBFS (8 bytes) and Mi Body Composition Scale (13+ bytes)
        """
        try:
            # Convert hex string to bytes
            data = bytes.fromhex(hex_data)
            
            if len(data) < 8:
                return None
            
            # MIBFS (Mi Body Fat Scale) uses different format
            if len(data) == 8:
                # For 8-byte MIBFS format: weight is in bytes 0-1 (little endian)
                weight_raw = struct.unpack('<H', data[0:2])[0]
                weight = weight_raw * 0.1356  # Calibrated scaling for MIBFS
                logger.info(f"⚖️ MIBFS weight: {weight:.1f}kg")
                return {"muscle_mass": 0, "body_fat": 0, "impedance": 0}
            elif len(data) >= 13:
                # For 13+ byte service data format with impedance
                # Control bytes
                control = struct.unpack('<H', data[0:2])[0]
                has_impedance = (control & (1 << 14)) != 0
                
                # Weight from bytes 11-12 or use control bytes with calibrated scaling
                if has_impedance:
                    weight_raw = control  # Use control bytes for weight
                    weight = weight_raw * 0.1356  # Same calibrated scaling
                else:
                    weight_raw = struct.unpack('<H', data[11:13])[0]
                    weight = weight_raw / 200.0
                
                # Impedance from bytes 9-10
                impedance = struct.unpack('<H', data[9:11])[0] if len(data) >= 11 else 0
                
                logger.info(f"⚖️ Service data weight: {weight:.1f}kg, Impedance: {impedance} ohms")
                
                # Calculate body composition if we have impedance and height
                body_fat = 0
                muscle_mass = 0
                if impedance > 0 and height_cm and height_cm > 100:
                    body_fat, muscle_mass = self.calculate_body_composition(weight, height_cm, impedance)
                
                return {"muscle_mass": muscle_mass, "body_fat": body_fat, "impedance": impedance}
            else:
                # For 13+ byte format: weight is in bytes 11-12 
                weight_raw = struct.unpack('<H', data[11:13])[0]
                weight = weight_raw / 200.0  # Convert to kg
                logger.info(f"⚖️ Standard format weight: {weight:.1f}kg")
            
            # Add to averaging buffer
            self.add_reading(weight, height_cm)
            
            # Additional body composition data (if available)
            if len(data) >= 16:
                # Body fat percentage (bytes 12-13)
                fat_raw = struct.unpack('<H', data[12:14])[0] 
                body_fat = fat_raw / 10.0
                
                # Muscle mass (bytes 14-15) 
                muscle_raw = struct.unpack('<H', data[14:16])[0]
                muscle_mass = muscle_raw / 10.0
                
                logger.info(f"📊 Raw reading: Weight={weight:.1f}kg, Muscle={muscle_mass:.1f}kg, Fat={body_fat:.1f}%")
                return {"muscle_mass": muscle_mass, "body_fat": body_fat}
            else:
                return {"muscle_mass": 0, "body_fat": 0}
                
        except Exception as e:
            logger.error(f"❌ Decoding error: {e}")
            return None
    
    def calculate_body_composition(self, weight_kg, height_cm, impedance_ohms):
        """Calculate body fat and muscle mass using impedance"""
        try:
            height_m = height_cm / 100.0
            bmi = weight_kg / (height_m * height_m)
            
            # Simplified body composition formulas using impedance
            # These are approximations - real algorithms are proprietary
            
            # Body fat percentage estimation
            # Based on impedance analysis principles
            body_fat_pct = max(5, min(50, (impedance_ohms / 10) - (height_cm / 4) + (weight_kg / 2)))
            
            # Muscle mass estimation
            # Higher impedance = less muscle mass
            muscle_mass_kg = weight_kg * (0.45 - (impedance_ohms - 400) / 2000)
            muscle_mass_kg = max(weight_kg * 0.2, min(weight_kg * 0.6, muscle_mass_kg))
            
            logger.info(f"🧮 Calculated: Body Fat={body_fat_pct:.1f}%, Muscle Mass={muscle_mass_kg:.1f}kg")
            
            return body_fat_pct, muscle_mass_kg
            
        except Exception as e:
            logger.error(f"❌ Body composition calculation error: {e}")
            return 0, 0
    
    def add_reading(self, weight, height_cm):
        """Add weight/height reading to 8-second averaging buffer"""
        current_time = time.time()
        
        # Start new collection period
        if not self.is_collecting:
            self.is_collecting = True
            self.reading_start_time = current_time
            self.weight_readings = []
            self.height_readings = []
            logger.info("🕐 Starting 8-second data collection...")
        
        # Add readings
        self.weight_readings.append(weight)
        if height_cm and height_cm > 100:  # Valid height
            self.height_readings.append(height_cm)
        
        # Check if 8 seconds elapsed
        if current_time - self.reading_start_time >= 8.0:
            self.finalize_measurement()
    
    def finalize_measurement(self):
        """Finalize measurement after 8 seconds of averaging"""
        if not self.weight_readings and not self.height_readings:
            logger.warning("⚠️ No readings to finalize")
            return
        
        # Calculate averaged values
        final_weight = self.calculate_mode_or_median(self.weight_readings) if self.weight_readings else 0
        final_height = self.calculate_mode_or_median(self.height_readings) if self.height_readings else 0
        
        # Calculate BMI using averaged values
        final_bmi = 0
        if final_weight > 0 and final_height > 0:
            height_m = final_height / 100.0
            final_bmi = round(final_weight / (height_m * height_m), 1)
        
        # Update latest data
        self.latest_data.update({
            "weight": final_weight,
            "height": final_height,
            "bmi": final_bmi,
            "muscle_mass": 0,  # Not available from scale
            "body_fat": 0,     # Not available from scale
            "timestamp": datetime.now().isoformat(),
            "status": "completed"
        })
        
        logger.info(f"📊 Final measurement: Weight={final_weight}kg, Height={final_height}cm, BMI={final_bmi}")
        
        # Send to credential processor
        self.send_to_credential_processor()
        
        # Save to Firebase (backup)
        self.save_to_firebase()
        
        # Reset for next measurement
        self.reset_measurement()
    
    def reset_measurement(self):
        """Reset measurement data and collection state for next reading"""
        self.is_collecting = False
        self.reading_start_time = None
        self.weight_readings = []
        self.height_readings = []
        self.latest_data["status"] = "waiting"
        logger.info("🔄 Measurement reset - ready for next reading")
    
    def send_to_credential_processor(self):
        """Send measurement data to credential processor"""
        try:
            response = requests.post(
                f"{self.credential_processor_url}/receive_measurement",
                json=self.latest_data,
                timeout=5
            )
            
            if response.status_code == 200:
                result = response.json()
                if result.get('success'):
                    logger.info(f"✅ Measurement sent to credential processor: {result.get('record', {}).get('measurement_id', 'unknown')}")
                else:
                    logger.warning(f"⚠️ Credential processor error: {result.get('error', 'unknown')}")
            else:
                logger.warning(f"⚠️ Credential processor HTTP error: {response.status_code}")
                
        except requests.exceptions.RequestException as e:
            logger.warning(f"⚠️ Could not reach credential processor: {e}")
        except Exception as e:
            logger.error(f"❌ Error sending to credential processor: {e}")
    
    def calculate_mode_or_median(self, readings):
        """Get most stable value from readings (mode or median)"""
        if not readings:
            return 0
        
        # Round to 1 decimal and find mode
        rounded = [round(r, 1) for r in readings]
        
        # Count frequencies
        freq = {}
        for val in rounded:
            freq[val] = freq.get(val, 0) + 1
        
        # Return most frequent value, or median if tie
        if freq:
            max_freq = max(freq.values())
            modes = [k for k, v in freq.items() if v == max_freq]
            return modes[0] if len(modes) == 1 else sorted(readings)[len(readings)//2]
        
        return sum(readings) / len(readings)
    
    def process_esp32_data(self, esp32_data):
        """Process combined data from ESP32 (BLE + height)"""
        try:
            hex_data = esp32_data.get('raw_data', '')
            height_cm = esp32_data.get('height', None)  # From ultrasonic sensor
            data_type = esp32_data.get('data_type', 'ble')
            
            # Handle height-only data
            if data_type == 'height_only' and height_cm:
                logger.info(f"📏 Height-only data: {height_cm}cm")
                
                # Create height-only measurement
                self.latest_data = {
                    "weight": 0,  # Blank for now
                    "height": round(height_cm, 1),
                    "bmi": 0,     # Blank for now
                    "muscle_mass": 0,
                    "body_fat": 0,
                    "timestamp": datetime.now().isoformat(),
                    "status": "height_only"
                }
                
                # Save to Firebase
                self.save_to_firebase(self.latest_data)
                return True
            
            # Handle BLE data (original logic)
            if hex_data:
                composition_data = self.decode_xiaomi_data(hex_data, height_cm)
                
                # Update muscle/fat if available
                if composition_data and self.latest_data["status"] == "success":
                    self.latest_data["muscle_mass"] = round(composition_data.get("muscle_mass", 0), 1)
                    self.latest_data["body_fat"] = round(composition_data.get("body_fat", 0), 1)
                
                return True
            return False
            
        except Exception as e:
            logger.error(f"❌ ESP32 data processing error: {e}")
            return False
    
    def save_to_firebase(self, data=None):
        """Save processed data to Firebase"""
        if not data:
            data = self.latest_data
        
        firebase_data = {
            "weight": data["weight"],
            "height": data["height"],
            "bmi": data["bmi"],
            "muscle_mass": data["muscle_mass"],
            "body_fat": data["body_fat"],
            "timestamp_ms": int(time.time() * 1000),
            "measurement_id": f"measurement_{int(time.time())}",
            "student_id": self.current_student_id or "test_user"
        }
        
        if not self.firebase_initialized or not self.db:
            logger.warning("⚠️ Firebase not connected - data available via API only")
            logger.info(f"📊 Latest data: {firebase_data}")
            return
        
        try:
            # Save to Firebase Realtime Database
            self.db.reference('/latest_measurement').set(firebase_data)
            if self.current_student_id:
                self.db.reference(f'/students/{self.current_student_id}/latest').set(firebase_data)
            self.db.reference(f'/measurements/{firebase_data["measurement_id"]}').set(firebase_data)
            
            logger.info(f"💾 Data saved to Firebase: {firebase_data}")
            
        except Exception as e:
            logger.error(f"❌ Firebase save failed: {e}")
            logger.info(f"📊 Data available via API: {firebase_data}")
    
    def start_server(self, host='0.0.0.0', port=8888):
        """Start TCP server to receive data from ESP32"""
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind((host, port))
            self.server_socket.listen(5)
            
            logger.info(f"🌐 Server listening on {host}:{port}")
            
            while True:
                try:
                    client_socket, address = self.server_socket.accept()
                    logger.info(f"📡 Connection from ESP32: {address}")
                    
                    # Handle client in separate thread
                    client_thread = threading.Thread(
                        target=self.handle_client, 
                        args=(client_socket,),
                        daemon=True
                    )
                    client_thread.start()
                    
                except Exception as e:
                    logger.error(f"❌ Server error: {e}")
                    
        except Exception as e:
            logger.error(f"❌ Failed to start server: {e}")
    
    def handle_client(self, client_socket):
        """Handle incoming data from ESP32"""
        try:
            while True:
                data = client_socket.recv(1024).decode('utf-8')
                if not data:
                    break
                
                logger.info(f"📨 Raw data received: {repr(data)}")
                
                # Skip empty or whitespace-only data
                cleaned_data = data.strip()
                if not cleaned_data:
                    logger.debug("⚠️ Received empty data, skipping...")
                    continue
                
                try:
                    # Parse JSON from ESP32
                    esp32_data = json.loads(cleaned_data)
                    
                    # Process the data (handles both BLE and height)
                    self.process_esp32_data(esp32_data)
                    
                except json.JSONDecodeError as e:
                    logger.error(f"❌ JSON decode error: {e}")
                    logger.error(f"❌ Raw data that failed: {repr(data)}")
                
        except Exception as e:
            logger.error(f"❌ Client handling error: {e}")
        finally:
            client_socket.close()
    
    def get_latest_data(self):
        """Get the latest decoded data"""
        return self.latest_data
    
    def set_current_student(self, student_id):
        """Set current student ID for measurements"""
        self.current_student_id = student_id
        logger.info(f"👤 Current student set: {student_id}")

# Global decoder instance
decoder = XiaomiScaleDecoder()

# Flask API for serving data to HTML pages
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/data', methods=['GET'])
def get_data():
    """Return latest decoded scale data"""
    return jsonify(decoder.get_latest_data())

@app.route('/set_student', methods=['POST'])
def set_student():
    """Set current student for measurements"""
    try:
        data = request.get_json()
        student_id = data.get('student_id', '')
        decoder.set_current_student(student_id)
        return jsonify({'status': 'success'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400

@app.route('/test', methods=['GET'])
def test_connection():
    """Test endpoint to verify server is running"""
    return jsonify({
        'status': 'server_running',
        'timestamp': datetime.now().isoformat(),
        'latest_data': decoder.get_latest_data()
    })

if __name__ == '__main__':
    print("🩺 ZENITH Xiaomi Scale Decoder Starting...")
    print("📡 Listening for ESP32 BLE data on port 8888")
    print("🌐 Flask API running on port 5000")
    print("🔗 Endpoints:")
    print("   GET  /data - Get latest scale data")
    print("   POST /set_student - Set current student")
    print("   GET  /test - Test server connection")
    
    # Start TCP server in separate thread
    server_thread = threading.Thread(target=decoder.start_server, daemon=True)
    server_thread.start()
    
    # Start Flask API
    app.run(host='0.0.0.0', port=5000, debug=True)
