#!/usr/bin/env python3
"""
Student Credential Processing Backend
Handles student form data and combines it with measurement data
Organizes data by STRAND-GRADE-SECTION folders in Firestore
"""

import json
import time
from datetime import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS
import firebase_admin
from firebase_admin import credentials, firestore
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

class StudentCredentialProcessor:
    def __init__(self):
        self.current_student = None
        self.measurement_data = None
        
        # Initialize Firebase
        try:
            if not firebase_admin._apps:
                # Try to use default credentials or service account file
                try:
                    # Option 1: Use service account file if it exists
                    cred = credentials.Certificate("zenith-software-2295d-firebase-adminsdk-fbsvc-28f21134ea.json")
                    firebase_admin.initialize_app(cred)
                except FileNotFoundError:
                    # Option 2: Use default credentials (if available)
                    firebase_admin.initialize_app()
                except Exception:
                    # Option 3: Skip Firebase for now
                    raise Exception("Firebase credentials not configured")
            
            self.db = firestore.client()
            self.firebase_initialized = True
            logger.info("🔥 Firebase Firestore connection ready")
        except Exception as e:
            logger.error(f"❌ Firebase initialization failed: {e}")
            logger.info("📝 Running without Firebase - data will only be logged")
            self.firebase_initialized = False
            self.db = None
    
    def process_student_info(self, student_data):
        """Process student information from form"""
        try:
            # Validate required fields
            required_fields = ['studentLRN', 'name', 'section', 'strand', 'grade', 'age', 'sex']
            for field in required_fields:
                if not student_data.get(field):
                    return {"error": f"Missing required field: {field}"}
            
            # Format section with leading zero if needed
            section = str(student_data['section']).zfill(2)
            
            # Create folder structure: STRAND-GRADE-SECTION
            folder_name = f"{student_data['strand'].upper()}-{student_data['grade']}{section}"
            
            # Store student credentials
            self.current_student = {
                "studentLRN": student_data['studentLRN'],
                "name": student_data['name'],
                "section": section,
                "strand": student_data['strand'].upper(),
                "grade": int(student_data['grade']),
                "age": int(student_data['age']),
                "sex": student_data['sex'],
                "folder_name": folder_name,
                "registration_time": datetime.now().isoformat(),
                "status": "registered"
            }
            
            logger.info(f"👤 Student registered: {self.current_student['name']} ({folder_name})")
            
            # Automatically trigger measurement process
            self.trigger_measurement_process()
            
            return {"success": True, "folder_name": folder_name, "student": self.current_student}
            
        except Exception as e:
            logger.error(f"❌ Student processing error: {e}")
            return {"error": str(e)}
    
    def trigger_measurement_process(self):
        """Automatically start measurement process when student registers"""
        try:
            import requests
            
            # Notify scale decoder to start active monitoring for this student
            scale_decoder_url = "http://localhost:5000"
            
            payload = {
                "student_id": self.current_student['studentLRN'],
                "name": self.current_student['name'],
                "action": "start_monitoring"
            }
            
            response = requests.post(
                f"{scale_decoder_url}/set_student",
                json=payload,
                timeout=3
            )
            
            if response.status_code == 200:
                logger.info(f"🚀 Automatic measurement started for {self.current_student['name']}")
                logger.info("📏 Student can now step on scale - measurements will be captured automatically")
            else:
                logger.warning(f"⚠️ Could not start automatic measurement: HTTP {response.status_code}")
                
        except Exception as e:
            logger.warning(f"⚠️ Could not trigger automatic measurement: {e}")
            logger.info("📝 Manual measurement mode - student will need to trigger measurements manually")
    
    def receive_measurement_data(self, measurement_data):
        """Receive measurement data from Python decoder"""
        try:
            self.measurement_data = {
                "weight": measurement_data.get('weight', 0),
                "height": measurement_data.get('height', 0),
                "bmi": measurement_data.get('bmi', 0),
                "muscle_mass": measurement_data.get('muscle_mass', 0),
                "body_fat": measurement_data.get('body_fat', 0),
                "timestamp": measurement_data.get('timestamp', datetime.now().isoformat()),
                "status": measurement_data.get('status', 'unknown')
            }
            
            logger.info(f"📊 Measurement data received: {self.measurement_data}")
            
            # Combine with student data if available
            if self.current_student:
                return self.finalize_student_record()
            else:
                logger.warning("⚠️ No student registered yet")
                return {"error": "No student registered"}
                
        except Exception as e:
            logger.error(f"❌ Measurement processing error: {e}")
            return {"error": str(e)}
    
    def finalize_student_record(self):
        """Combine student credentials with measurement data and save to Firestore"""
        try:
            if not self.current_student or not self.measurement_data:
                return {"error": "Missing student or measurement data"}
            
            # Create final record
            final_record = {
                **self.current_student,
                "measurements": self.measurement_data,
                "measurement_id": f"{self.current_student['studentLRN']}_{int(time.time())}",
                "completed_time": datetime.now().isoformat()
            }
            
            # Save to Firestore organized by folder
            if self.firebase_initialized and self.db:
                folder_name = self.current_student['folder_name']
                
                # Save to organized structure
                doc_ref = self.db.collection('students').document(folder_name).collection('records').document(final_record['measurement_id'])
                doc_ref.set(final_record)
                
                # Also save to latest for quick access
                latest_ref = self.db.collection('latest_measurements').document(self.current_student['studentLRN'])
                latest_ref.set(final_record)
                
                logger.info(f"💾 Student record saved to Firestore: {folder_name}/{final_record['measurement_id']}")
            else:
                logger.info(f"📊 Final record (Firebase disabled): {final_record}")
            
            # Reset for next student
            self.current_student = None
            self.measurement_data = None
            
            return {"success": True, "record": final_record}
            
        except Exception as e:
            logger.error(f"❌ Finalization error: {e}")
            return {"error": str(e)}

# Global processor instance
processor = StudentCredentialProcessor()

# API Endpoints
@app.route('/register_student', methods=['POST'])
def register_student():
    """Register student from form data"""
    try:
        student_data = request.get_json()
        result = processor.process_student_info(student_data)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/receive_measurement', methods=['POST'])
def receive_measurement():
    """Receive measurement data from Python decoder"""
    try:
        measurement_data = request.get_json()
        result = processor.receive_measurement_data(measurement_data)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/get_current_student', methods=['GET'])
def get_current_student():
    """Get current registered student"""
    if processor.current_student:
        return jsonify(processor.current_student)
    else:
        return jsonify({"error": "No student registered"}), 404

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "firebase_connected": processor.firebase_initialized,
        "current_student": processor.current_student is not None,
        "measurement_ready": processor.measurement_data is not None
    })

if __name__ == '__main__':
    print("👤 ZENITH Student Credential Processor Starting...")
    print("🌐 API running on port 5001")
    print("🔗 Endpoints:")
    print("   POST /register_student - Register student from form")
    print("   POST /receive_measurement - Receive measurement data")
    print("   GET  /get_current_student - Get current student")
    print("   GET  /health - Health check")
    
    app.run(host='0.0.0.0', port=5001, debug=True)
