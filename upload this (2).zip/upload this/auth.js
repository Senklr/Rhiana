import { 
    getFirestore, doc, getDoc, setDoc 
} from "firebase/firestore";
import { 
    getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, 
    onAuthStateChanged, sendEmailVerification 
} from "firebase/auth";
import { app } from "./firebase-config.js"; // Ensure Firebase is initialized

const db = getFirestore(app);
const auth = getAuth(app);

// ================= SIGN UP HANDLER =================
const signupForm = document.getElementById("signup-form");
if (signupForm) {
    signupForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const email = document.getElementById("signup-email").value;
        const password = document.getElementById("signup-password").value;
        const adminCode = document.getElementById("admin-code").value.trim();

        try {
            // Create user in Firebase Auth
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            const user = userCredential.user;

            // Determine role (admin or nurse)
            let role = "nurse";
            if (adminCode === "SUPERSECRET123") { // <-- replace with your secret admin code
                role = "admin";
            }

            // Save user data to Firestore with extended fields
            await setDoc(doc(db, "users", user.uid), {
                uid: user.uid,
                email: user.email,
                fullName: user.displayName || null,
                badge: null, // Not collected in basic signup
                phone: null, // Not collected in basic signup
                role: role,
                requestedAdmin: role === 'admin',
                emailVerified: user.emailVerified || false,
                createdAt: new Date()
            });

            // Send verification email
            await sendEmailVerification(user);
            alert("✅ Account created! Please check your email to verify.");

        } catch (error) {
            console.error("❌ Signup error:", error);
            alert(error.message);
        }
    });
}

// ================= LOGIN HANDLER =================
const loginForm = document.getElementById("login-form");
if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const email = document.getElementById("login-email").value;
        const password = document.getElementById("login-password").value;

        try {
            await signInWithEmailAndPassword(auth, email, password);
            console.log("✅ Login successful");
        } catch (error) {
            console.error("❌ Login error:", error);
            alert(error.message);
        }
    });
}

// ================= AUTH STATE LISTENER =================
onAuthStateChanged(auth, async (user) => {
    if (user) {
        if (!user.emailVerified) {
            console.warn("⚠️ Email not verified!");
            alert("Please verify your email before continuing.");
            return;
        }

        const userRef = doc(db, "users", user.uid);
        const userDoc = await getDoc(userRef);

        if (!userDoc.exists()) {
            console.error("❌ No Firestore document found for user!");
            return;
        }

        const userData = userDoc.data();
        console.log("✅ User data:", userData);

        // Redirect based on role
        if (userData.role === "admin") {
            window.location.assign("settings.html"); // Admin settings page
        } else if (userData.role === "nurse") {
            window.location.assign("nurseview.html"); // Nurse dashboard
        } else {
            console.warn("⚠️ Unknown role:", userData.role);
        }
    } else {
        console.log("⚠️ No user logged in.");
    }
});
